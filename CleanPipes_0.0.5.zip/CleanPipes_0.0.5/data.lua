require("prototypes.entity.entities")
require("prototypes.items")
require("prototypes.recipes")