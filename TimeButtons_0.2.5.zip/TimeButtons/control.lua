require "defines"

white = {r = 1, g = 1, b = 1}
red = {r = 1, g = 0, b = 0} 
green = {r = 0, g = 1, b = 0}
yellow = {r = 1, g = 1, b = 0}
init = 0
debug_timebuttons = 0

local tbgui =
{
  type="frame_style",
  parent="frame_style",
  graphical_set=
  {
    type = "monolith",
    top_monolith_border = 1,
    right_monolith_border = 1,
    bottom_monolith_border = 1,
    left_monolith_border = 1,
    monolith_image =
    {
      filename = "__TimeButtons__/resources/GUI/50x120.png",
      width = 120,
      height = 50,
      x = 0,
      y = 0
    }
  }
}


game.on_init(function()
	init = 0
	debug_timebuttons = 0;
 end)
 
game.on_load (function()
	init = 0
end)

game.on_save (function()
	if game.player.gui.top.menu_tb ~= nil then game.player.gui.top.menu_tb.destroy() end
	if game.player.gui.top.tb_frame ~= nil then 
		game.player.gui.top.tb_frame.destroy()
	end
	
	if debug_timebuttons == 1 then game.player.print("DEBUG: SAVE AND CLEAR GUI") end
end)

game.on_event(defines.events.on_gui_click, function(event)

     -- handle on gui click
	 --game.player.print(event.element.name)
		-- obsługa przycskow predkosci
		
		local x1,y1
		x1, y1 = string.find(event.element.name, "timebutton")
		if x1 ~= nil then
			local button_no = tonumber(string.sub(event.element.name, y1+1))      -- from character 7 until the end
			local button_speed = global.button_speed[button_no]
			game.speed = button_speed
			detect_speed_color_red()
		end
		-- end obsługa przycskow predkosci

		if event.element.name == "menubutton" then
			global.button_menu_timer = 10
		end

		if event.element.name == "timedec" then
			if global.button_count-1 >= 2 then 
				for i=1, global.button_count, 1 do
					local row_no = i+1
					global.button_caption[i] = game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_0_" .. i].text
					if tonumber(game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].text) ~= nil then
						global.button_speed[i] = tonumber(game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].text)
					end
				end
				global.button_count = global.button_count - 1
				global.refreshmenu = true
				table.remove(global.button_speed, #global.button_speed)
				table.remove(global.button_caption, #global.button_caption)

			else
			game.player.print("The minimum number of time buttons is 2")
			end
		end
		
		if event.element.name == "timeinc" then
			if global.button_count+1 <=10 then 
				for i=1, global.button_count, 1 do
					local row_no = i+1
					global.button_caption[i] = game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_0_" .. i].text
					if tonumber(game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].text) ~= nil then
						global.button_speed[i] = tonumber(game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].text)
					end
				end
				global.button_count = global.button_count + 1
				global.refreshmenu = true
				global.button_caption[#global.button_caption+1] = "x1"
				global.button_speed[#global.button_speed+1] = 1

			else
				game.player.print("Limit the number of time buttons reached")
			end
		end
	
			
		if event.element.name == "time_button_menu_end" then
			if game.player.gui.top.menu_tb~=nil then
			
	
				for i=1, global.button_count, 1 do
					local row_no = i+1
					global.button_caption[i] = game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_0_" .. i].text
					if tonumber(game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].text) ~= nil then
						global.button_speed[i] = tonumber(game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].text)
					end
				end
				

				if tonumber(game.player.gui.top.menu_tb.row_0.text_noofbuttons.text) ~= nil then				
					global.button_count = tonumber(game.player.gui.top.menu_tb.row_0.text_noofbuttons.text)
				end
				
				if tonumber(game.player.gui.top.menu_tb.row_preend2.tbtfield1.text) ~= nil then				
					global.speedatcrafting = tonumber(game.player.gui.top.menu_tb.row_preend2.tbtfield1.text)
				end
				
				if game.player.gui.top.menu_tb.row_preend1.CheckBoxtb_row_preend2.state == false then global.chspeedoncraftingonoff = false
				elseif game.player.gui.top.menu_tb.row_preend1.CheckBoxtb_row_preend2.state == true then global.chspeedoncraftingonoff = true
				end
				
					
				game.player.gui.top.menu_tb.destroy()
				
				global.build = true
				global.destroy = false
				global.button_menu_timer = 0


			end
		end
		
		
	

end)

game.on_event(defines.events.on_tick, function(event)

if init == 0 then
	init = 1
	
	init_all()
	--game.player.print("on load")

	--kompatybilność z wersją < 0.0.4
	kompatybilnosc()
	-- end kompatybilność z wersją < 0.0.4

	--kompatybilność z wersją < 0.2.0
	kompatybilnosc_2_deleteall()
	-- end kompatybilność z wersją < 0.2.0
end

--[[DEBUG
	game.player.clearconsole()
if global.rlesssto == false then txxt = "global.rlesssto false" else txxt = "global.rlesssto true" end
game.player.print(txxt)
if global.rbiggersto == false then txxt = "global.rbiggersto false" else txxt = "global.rbiggersto true" end
game.player.print(txxt)
game.player.print("global.button_menu_timer " .. global.button_menu_timer)
if global.build == false then txxt = "false" else txxt = "true" end
game.player.print("global.build " .. txxt)
if global.destroy == false then txxt = "false" else txxt = "true" end
game.player.print("global.destroy " .. txxt)--]]
	
	
	
if game.tick%5==0 then
--game.player.print(global.button_menu_timer)
--[[game.player.print(global.button_speed[1])
game.player.print(global.button_speed[2])
game.player.print(global.button_speed[3])
game.player.print(global.button_speed[4])
game.player.print(global.button_speed[5])
game.player.print(global.button_speed[6])]]--

local curpos = {x=200, y=200} 

local error_l, error_h = pcall(function()
		--curpos = game.player.cursorposition
		end)
		
if error_l then
--curpos = game.player.cursorposition
end

	--game.player.print("x=" .. curpos.x)
	--game.player.print("y=" .. curpos.y)
	local r = math.sqrt(curpos.x*curpos.x+curpos.y*curpos.y)
	
	if r < 100  then
		global.rlesssto = true
		global.rbiggersto = false
	end
	
	if global.rlesssto == true then
		global.button_menu_timer=global.button_menu_timer+1
		if r > 100 then
			global.rbiggersto = true
			if global.build == true then global.build = false else global.build = true end 
			if global.destroy == true then global.destroy = false else global.destroy = true end 
			global.rlesssto = false
			global.button_menu_timer=0
		end
	end
	

	if global.button_menu_timer == 10 then -- wyswietl menu i usun przyciski
		draw_time_menu()
		global.build = false
		global.destroy = true
	end
	
	
	if global.build == global.destroy then
		global.build = true
		global.destroy = false
	end

	if global.build == true and game.player.gui.top.menu_tb == nil then -- create time buttons
		--game.player.print("create time buttons")
		
		add_buttons()
		
	end

	if global.destroy == true then  -- delete time buttons
		delete_all()
	end
	
	if global.refreshmenu == true then
		global.refreshmenu = false
		game.player.gui.top.menu_tb.destroy()
		draw_time_menu()
	end

end


auto_ch_speed_when_crafting()


end)

function all_yellow()
	for i=1, global.button_count, 1 do
		if game.player.gui.top.tb_frame ~= nil then
			game.player.gui.top.tb_frame["timebutton" .. i].style.font_color = yellow
			speed_detected = true
		end
	end
	game.player.print("Actual Game Speed is " .. game.speed)
end

function all_white()
	for i=1, global.button_count, 1 do
		if game.player.gui.top.tb_frame ~= nil then
			game.player.gui.top.tb_frame["timebutton" .. i].style.font_color = white
			speed_detected = true
		end
	end
end

function detect_speed_color_red()
local speed_detected = false
	
	all_white()

	for i=1, global.button_count, 1 do
		if game.speed == global.button_speed[i] then
			if game.player.gui.top.tb_frame ~= nil then
				game.player.gui.top.tb_frame["timebutton" .. i].style.font_color = red
				speed_detected = true
			end
		end
	end
	
	if speed_detected == false then
		all_yellow()
	end
	
end

function add_buttons()

	if game.player.gui.top.tb_frame == nil then
	
		game.player.gui.top.add({type="frame", name="tb_frame", caption="",direction="horizontal", style="tbgui"}) --, style="tbgui"
				
		game.player.gui.top.tb_frame.add({type = "button", name="menubutton", caption="M", font_color = white, style="time_button"})
	
		for i=1, global.button_count, 1 do
			if game.player.gui.top.tb_frame ~= nil then
				
				game.player.gui.top.tb_frame.add({type = "button", name="timebutton" .. i, caption=global.button_caption[i], font_color = white, style="time_button"})
				
			end
		end
		
		detect_speed_color_red()
	end
	
end

function delete_all()

if game.player.gui.top.tb_frame ~= nil then game.player.gui.top.tb_frame.destroy() end

end

function init_all()

--compatibility with advanced equipnemt

	if game.player.gui.top.time_frame == nil then
		if game.player.gui.top.blank1 == nil then
			game.player.gui.top.add({type="frame", name="blank1", caption="",direction="vertical"})
			game.player.gui.top.blank1.style.minimal_width = 120
		end
	end
	
	if game.player.gui.top.live_frame == nil then
		if game.player.gui.top.blank2 == nil then
			game.player.gui.top.add({type="frame", name="blank2", caption="",direction="vertical"})
			game.player.gui.top.blank2.style.minimal_width = 120
		end
	end
	
	if game.player.gui.top.time_frame ~= nil and game.player.gui.top.blank1 ~= nil then game.player.gui.top.blank1.destroy() end
	if game.player.gui.top.live_frame ~= nil and game.player.gui.top.blank2 ~= nil then game.player.gui.top.blank2.destroy() end
	
--end compatibility with advanced equipnemt
	
	--if game.player.gui.top.butt == nil then
	--	game.player.gui.top.add({type="frame", name="butt", caption="",direction="horizontal", style="tbgui"})
	--end
	
	if global.build == nil then
		global.build = true
	end
	if global.destroy == nil then
		global.destroy = false
	end
	if global.rlesssto == nil then
		global.rlesssto = false
	end
	if global.rbiggersto == nil then
		global.rbiggersto = false
	end
	
	if global.button_count == nil then
		global.button_count = 5
	end	
	
	if global.button_caption == nil then
		global.button_caption = {"x0.5", "x1", "x2", "x5", "x10"}
	end	
	
	if global.button_speed == nil then
		global.button_speed = {0.5, 1, 2 ,5 ,10 , 20}
	end	

	if global.button_menu_timer == nil then
		global.button_menu_timer = 0
	end
	
	if global.chspeedoncraftingonoff == nil then
		global.chspeedoncraftingonoff = false
	end
	
	if global.speedatcrafting == nil then
		global.speedatcrafting = 2
	end
	
	if global.speedatstartcrafting == nil then
		global.speedatstartcrafting = 0
	end
	
	if global.timebuttons_compatibility == nil then
		global.timebuttons_compatibility = {false,false}
	end
	
end

function draw_time_menu()
			if game.player.gui.top.menu_tb == nil then
			
				game.player.gui.top.add({type="frame", name="menu_tb", caption="                   Time Buttons Menu",direction="vertical"})
				--game.player.gui.top.menu_tb.style.align = "center"
				
				game.player.gui.top.menu_tb.add({type="flow",name="row_0",direction="horizontal"})
				game.player.gui.top.menu_tb.row_0.add({type="label", name="label_menu_0", caption="Number of time buttons:"})
				game.player.gui.top.menu_tb.row_0.add({type="textfield", name="text_noofbuttons", caption="", style="tb_textfield_style"})
					game.player.gui.top.menu_tb.row_0.text_noofbuttons.caption = global.button_count
				game.player.gui.top.menu_tb.row_0.add({type="button", name="timedec", caption=" - "})
				game.player.gui.top.menu_tb.row_0.add({type="button", name="timeinc", caption=" + "})
					mw = 35
					game.player.gui.top.menu_tb.row_0.timeinc.style.maximal_width=mw
					game.player.gui.top.menu_tb.row_0.timeinc.style.minimal_width=mw
					game.player.gui.top.menu_tb.row_0.timedec.style.maximal_width=mw
					game.player.gui.top.menu_tb.row_0.timedec.style.minimal_width=mw	
				
				game.player.gui.top.menu_tb.add({type="flow",name="row_1",direction="horizontal"})
				game.player.gui.top.menu_tb.row_1.add({type="label", name="label_menu_0", caption=" "})
				game.player.gui.top.menu_tb.row_1.add({type="label", name="label_menu_1", caption="Name"})
				game.player.gui.top.menu_tb.row_1.add({type="label", name="label_menu_4", caption=" "})
				game.player.gui.top.menu_tb.row_1.add({type="label", name="label_menu_2", caption="Speed"})
				--game.player.gui.top.menu_tb.row_1.add({type="label", name="label_menu_5", caption=" "})
			--	game.player.gui.top.menu_tb.row_1.add({type="label", name="label_menu_3", caption="ON/OFF"})
					game.player.gui.top.menu_tb.row_1.label_menu_1.style.font="default-bold"
					game.player.gui.top.menu_tb.row_1.label_menu_2.style.font="default-bold"
				--	game.player.gui.top.menu_tb.row_1.label_menu_3.style.font="default-bold"
					game.player.gui.top.menu_tb.row_1.label_menu_0.style.minimal_width=81
					game.player.gui.top.menu_tb.row_1.label_menu_1.style.minimal_width=40
					game.player.gui.top.menu_tb.row_1.label_menu_2.style.minimal_width=40
				--	game.player.gui.top.menu_tb.row_1.label_menu_3.style.minimal_width=40
					game.player.gui.top.menu_tb.row_1.label_menu_4.style.minimal_width=33
				--	game.player.gui.top.menu_tb.row_1.label_menu_5.style.minimal_width=21
		
				for i=1, global.button_count, 1 do
					local row_no = i+1
					game.player.gui.top.menu_tb.add({type="flow",name="row_" .. row_no,direction="horizontal"})
					game.player.gui.top.menu_tb["row_" .. row_no].add({type="label", name="label_menu_4", caption="Button " .. i .. ":"})
					game.player.gui.top.menu_tb["row_" .. row_no].add({type="textfield", name="text_menu_0_" .. i, caption="", style="tb_textfield_style"}) -- style="textfield_style"})
					game.player.gui.top.menu_tb["row_" .. row_no].add({type="textfield", name="text_menu_1_" .. i, caption="", style="tb_textfield_style"})
						game.player.gui.top.menu_tb["row_" .. row_no].label_menu_4.style.font="default-bold"
						local mw=80
						game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_0_" .. i].style.maximal_width=mw
						game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].style.maximal_width=mw
						game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_0_" .. i].style.minimal_width=mw
						game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].style.minimal_width=mw
						mw=34
						game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_0_" .. i].style.minimal_height=mw
						game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].style.minimal_height=mw
						game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_0_" .. i].caption = global.button_caption[i]
						game.player.gui.top.menu_tb["row_" .. row_no]["text_menu_1_" .. i].caption = global.button_speed[i]
					
				end
		
				game.player.gui.top.menu_tb.add({type="flow",name="row_preend1",direction="horizontal"})
				game.player.gui.top.menu_tb.row_preend1.add({type="checkbox", name="CheckBoxtb_row_preend2", caption="Check me and when you start crafting game", state=false})
					if global.chspeedoncraftingonoff == false then game.player.gui.top.menu_tb.row_preend1.CheckBoxtb_row_preend2.state = false
					elseif global.chspeedoncraftingonoff == true then game.player.gui.top.menu_tb.row_preend1.CheckBoxtb_row_preend2.state = true
					end
				
				game.player.gui.top.menu_tb.add({type="flow",name="row_preend2",direction="horizontal"})
				game.player.gui.top.menu_tb.row_preend2.add({type="label", name="label_menu_10", caption="speed will change to:"})				
				game.player.gui.top.menu_tb.row_preend2.add({type="textfield", name="tbtfield1", caption="", style="tb_textfield_style"})
				game.player.gui.top.menu_tb.row_preend2.add({type="label", name="label_menu_11", caption="and after crafting is"})
					game.player.gui.top.menu_tb.row_preend2.tbtfield1.caption = global.speedatcrafting
				
				game.player.gui.top.menu_tb.add({type="flow",name="row_preend3",direction="vertical"})
				game.player.gui.top.menu_tb.row_preend3.add({type="label", name="label_menu_12", caption="finished it will return to previous value unless you"})
				game.player.gui.top.menu_tb.row_preend3.add({type="label", name="label_menu_13", caption="change game speed during crafting."})
				
				
				game.player.gui.top.menu_tb.add({type="flow",name="row_end",direction="horizontal"})
				game.player.gui.top.menu_tb.row_end.add({type="button", name="time_button_menu_end", caption="SAVE AND CLOSE"})
					game.player.gui.top.menu_tb.row_end.time_button_menu_end.style.font="default-bold"
					mw=315
					game.player.gui.top.menu_tb.row_end.time_button_menu_end.style.maximal_width=mw
					game.player.gui.top.menu_tb.row_end.time_button_menu_end.style.minimal_width=mw	
				
				
					
			end
end

function kompatybilnosc()
	if global.timebuttons_compatibility[1] == false then
		global.timebuttons_compatibility[1] = true
		if game.player.gui.top.button_x05 ~= nil then game.player.gui.top.button_x05.destroy() end
		if game.player.gui.top.button_x1 ~= nil then game.player.gui.top.button_x1.destroy() end
		if game.player.gui.top.button_x2 ~= nil then game.player.gui.top.button_x2.destroy() end
		if game.player.gui.top.button_x5 ~= nil then game.player.gui.top.button_x5.destroy() end
		if game.player.gui.top.button_x10 ~= nil then game.player.gui.top.button_x10.destroy() end
		if game.player.gui.top.button_x20 ~= nil then game.player.gui.top.button_x20.destroy() end	
	end
end

function auto_ch_speed_when_crafting()
	if global.chspeedoncraftingonoff == true then
		if game.tick%5==0 then
		local speedatcraft = global.speedatcrafting
			if game.player.crafting_queue_size > 0 then
				if global.speedatstartcrafting == 0 then
					global.speedatstartcrafting = game.speed 
					game.speed = speedatcraft
					detect_speed_color_red()
				end
			else
				if game.speed == speedatcraft and global.speedatstartcrafting ~= 0 then
					game.speed = global.speedatstartcrafting
					detect_speed_color_red()
				end
				if global.speedatstartcrafting ~= 0 then global.speedatstartcrafting = 0 end
			end
		end
	end	
end

function kompatybilnosc_2_deleteall()
	if global.timebuttons_compatibility[2] == false then
		global.timebuttons_compatibility[2] = true
		
		--kasuj istniejace buttonsy
		if global.button_names ~= nil then
			for i=1, #global.button_names, 1 do
				if game.player.gui.top[global.button_names[i]] ~= nil then game.player.gui.top[global.button_names[i]].destroy() end
			end 
		end--kasuj istniejace buttonsy
		
		if global.button_onoff ~= nil then
			global.button_onoff = nil
		end	
		
		if global.button_buttons ~= nil then
			global.button_buttons = nil
		end		
		
		if global.button_on ~= nil then
			global.button_on = nil
		end
		
		if global.builded ~= nil then
			global.builded = nil
		end
		
		if global.button_names ~= nil then
			global.button_names = nil
		end

		if global.refreshmenu ~= nil then
			global.refreshmenu = false
		end
		
		if global.button_caption ~= nil then global.button_caption = nil end
		if global.button_caption == nil then
			global.button_caption = {"x0.5", "x1", "x2", "x5", "x10"}
		end	
		
		if global.button_speed ~= nil then global.button_speed = nil end
		if global.button_speed == nil then
			global.button_speed = {0.5, 1, 2 ,5 ,10} 
		end	

	end
end