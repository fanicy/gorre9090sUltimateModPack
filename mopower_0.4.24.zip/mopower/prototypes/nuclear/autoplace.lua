data:extend(
{
  {
    type = "noise-layer",
    name = "nuclear-ores"
  },
  {
    type = "autoplace-control",
    name = "uranium-ore",
    richness = true,
    order = "u"
  }
}
)