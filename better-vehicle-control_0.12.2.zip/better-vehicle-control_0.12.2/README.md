# better-vehicle-control
 Factorio mod that tweak vehicle control to be easier.
