require "defines"
require "config"

local WAREHOUSING_VERSION = "0.0.5"


