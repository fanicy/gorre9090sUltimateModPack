data.mocombat = true

MoConfig = MoConfig or {} --Create a empty table to store our config in

require("config")
require("crossmod.detectmod")
require("prototypes.damage-type")
require("prototypes.lweps.base")
require("prototypes.defence.base")
require("prototypes.aliens.base")
require("prototypes.armor.base")
require("prototypes.vehicles.base")
require("base-edits")
