--Vanilla Mod Settings.

MoConfig.ModCompat = {}
local MC = MoConfig.ModCompat

MC.CombatBotsResearch = {"robotics","combat-robotics"}