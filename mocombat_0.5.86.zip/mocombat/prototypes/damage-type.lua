data:extend(
{
  {
    type = "damage-type",
    name = "plasma"
  },
  {
    type = "damage-type",
    name = "electric"
  },
  {
    type = "damage-type",
    name = "nanocloud"
  },
  {
    type = "damage-type",
    name = "armor-piercing"
  }  
}
)
