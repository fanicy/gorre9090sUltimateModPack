local M = MoConfig

if M.PowerArmorMods then
	require("batteries")
	require("shields")
	require("reactors")
end
