local recipepadding = 1

--Fonts
data:extend(
{
  {
    type = "font",
    name = "tm-small",
    from = "default",
    size = 12
  }
}
)
--Styles
data.raw["gui-style"].default["tm-dropdown-frame"] = {
	type = "frame_style",
	parent = "frame_style",
	font = "default-bold",
  title_top_padding = 0,
  title_left_padding = 0,
  title_bottom_padding = 0,
  title_right_padding = 0,
  -- padding of the content area of the frame
  top_padding  = 0,
  right_padding = 0,
  bottom_padding = 0,
  left_padding = 0,
  flow_style=
  {
    horizontal_spacing = 0,
    vertical_spacing = 0
  }
}


data.raw["gui-style"].default["tm-item-button"] = {
	type = "button_style",
	parent = "slot_button_style",
	font = "tm-small",
	width = 72,
	height = 36
}

data.raw["gui-style"].default["tm-settings-button"] = {
	type = "button_style",
	parent = "controls_settings_button_style",
	font = "tm-small",
  minimal_width = 36
}
data.raw["gui-style"].default["tm-popup-button"] = {
	type = "button_style",
	parent = "slot_button_style",
	font = "tm-small",
	width  = 48,
	height = 24
}

data.raw["gui-style"].default["tm-icon-style"] = {
  type = "checkbox_style",
  --parent = "checkbox_style",
  font = "default",
  font_color = {r=1, g=1, b=1},
  width = 35,
  height = 35,
  hovered_background =
  {
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    width = 32,
    height = 32,
    x = 0,
    y = 0
  },
  clicked_background =
  {
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    width = 32,
    height = 32,
    x = 0,
    y = 0
  },
  checked =
  {
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    width = 32,
    height = 32,
    x = 65,
    y = 0
  }
}

data.raw["gui-style"].default["tm-recipe-crafting"] = {
  type = "frame_style",
  font = "default-bold",
  font_color = {r=1, g=1, b=1},
  title_top_padding = 0,
  title_left_padding = 0,
  title_bottom_padding = 0,
  title_right_padding = 0,
  top_padding  = 0,
  right_padding = 0,
  bottom_padding = 7,
  left_padding = 1,
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {0, 32}
  },
  flow_style=
  {
    horizontal_spacing = 0,
    vertical_spacing = 0
  }
}

data.raw["gui-style"].default["tm-recipe-advanced-crafting"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {14, 32}
  }
}

data.raw["gui-style"].default["tm-recipe-smelting"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {7, 32}
  }
}

data.raw["gui-style"].default["tm-recipe-chemistry"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {28, 32}
  }
}

data.raw["gui-style"].default["tm-recipe-crafting-with-fluid"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {35, 32}
  }
}

data.raw["gui-style"].default["tm-recipe-oil-processing"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {21, 32}
  }
}

data.raw["gui-style"].default["tm-recipe-unknown"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {42, 32}
  }
}

--Frame "holes"
---------------
data.raw["gui-style"].default["tm-recipe-crafting-hole"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {0, 39}
  }
}

data.raw["gui-style"].default["tm-recipe-advanced-crafting-hole"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {14, 39}
  }
}

data.raw["gui-style"].default["tm-recipe-smelting-hole"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {7, 39}
  }
}

data.raw["gui-style"].default["tm-recipe-chemistry-hole"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {28, 39}
  }
}

data.raw["gui-style"].default["tm-recipe-crafting-with-fluid-hole"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {35, 39}
  }
}

data.raw["gui-style"].default["tm-recipe-oil-processing-hole"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {21, 39}
  }
}

data.raw["gui-style"].default["tm-recipe-unknown-hole"] = {
  type = "frame_style",
  parent="tm-recipe-crafting",
  graphical_set =
  {
    type = "composition",
    filename = "__test-mode__/graphics/gui.png",
    priority = "extra-high-no-scale",
    corner_size = {3, 3},
    position = {42, 39}
  }
}

--[[
data:extend(
{
  {
    type = "gui-style",
    name = "default",
    tm_progressbar_style =
    {
      type = "progressbar_style",
      progressbar_type = "diode"
    }
	}		
})

      diode_bar =
      {

        width = 20,
        height = 20,
      }

--]]