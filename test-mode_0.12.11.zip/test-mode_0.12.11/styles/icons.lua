-- 1. loop types
-- 2. find "item" kind of type by checking stack_size
-- 3. create icon style for every "item"
-- 0.12.1 support for fluid icons => take icon from all fluid types.

for typename, sometype in pairs(data.raw) do
  local _, object = next(sometype)
  if object.stack_size or typename == "fluid" then
    for name, item in pairs(sometype) do
      if item.icon then
        data.raw["gui-style"].default["tm-icon-"..name] =
        {
        	type = "checkbox_style",
          parent = "tm-icon-style",
          default_background =
          {
            filename = item.icon,
            width = 32,
            height = 32
          },
          hovered_background =
          {
            filename = item.icon,
            width = 32,
            height = 32
          }
        }
        
        data.raw["gui-style"].default["tm-icon-frame-"..name] = {
           type = "frame_style",
          parent = "tm-dropdown-frame",
          width = 32,
          height = 32,
          graphical_set =
          {
            type = "monolith",
            top_monolith_border = 1,
            right_monolith_border = 0,
            bottom_monolith_border = 1,
            left_monolith_border = 0,
            monolith_image =
            {
              filename = item.icon,
              priority = "extra-high-no-scale",
              width = 32,
              height = 32,
              x = 0,
              y = 0
            }
          }
        }
      end
    end
  end
end
