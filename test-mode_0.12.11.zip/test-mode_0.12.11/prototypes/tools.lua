data:extend(
{
  {
    type = "item-group",
    name = "test-mode",
    order = "tm",
    inventory_order = "tm",
    icon = "__test-mode__/graphics/tm-icon.png"
  },
  {
    type = "item-subgroup",
    name = "tools",
    group = "test-mode",
    order = "a",
  },
  
  
  
  {
    type = "mining-tool",
    name = "mjollnir",
    icon = "__test-mode__/graphics/enchanted-stone-axe.png",
    flags = {"goes-to-quickbar"},
    damage = 1337,
    durability = 10000,
    subgroup = "tools",
    order = "a[test-mode]-a[mjollnir]",
    speed = 5,
		place_result = "mjollnir",
    stack_size = 32
  },
  {
    type = "container",
    name = "mjollnir",
    icon = "__test-mode__/graphics/empty.png",
    flags = {"placeable-neutral", "player-creation","placeable-off-grid"},
    max_health = 1337,
    corpse = "tm-marker",
		--dying_explosion = "huge-lightning",
    inventory_size = 1,
    picture =
    {
      filename = "__test-mode__/graphics/cursor.png",
      width = 32,
      height = 32,
      shift = {0, 0}
    }
  },
  {
    type = "corpse",
    name = "tm-marker",
    icon = "__test-mode__/graphics/marker.png",
    flags = {"placeable-neutral", "not-on-map", "placeable-off-grid"},
    selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
    selectable_in_game = false,
    order="d[remnants]-a[generic]-a[small]",
    time_before_removed = 600,
    final_render_layer = "remnants",
    animation = 
    {
      {
        width = 32,
        height = 32,
        frame_count = 1,
        direction_count = 1,
        filename = "__test-mode__/graphics/marker.png",
        shift = {0, -0.5}
      }
    }
  },
  
  
  
  {
    type = "item",
    name = "tm-solar-panel",
    icon = "__base__/graphics/icons/solar-panel.png",
    flags = {"goes-to-quickbar"},
    subgroup = "tools",
    order = "a[test-mode]-b[tm-solar-panel]",
    place_result = "tm-solar-panel",
    stack_size = 50
  },
  {
    type = "solar-panel",
    name = "tm-solar-panel",
    icon = "__base__/graphics/icons/solar-panel.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "tm-solar-panel"},
    max_health = 100,
    corpse = "big-remnants",
    collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
    selection_box = {{-1.5, -1.5}, {1.5, 1.5}},
    energy_source =
    {
      type = "electric",
      usage_priority = "solar"
    },
    picture =
    {
      filename = "__base__/graphics/entity/solar-panel/solar-panel.png",
      priority = "high",
      width = 104,
      height = 96
    },
    production = "1GW"
  },
  
  {
    type = "item",
    name = "tm-electric-pole",
    icon = "__base__/graphics/icons/big-electric-pole.png",
    flags = {"goes-to-quickbar"},
    subgroup = "tools",
    order = "a[test-mode]-c[tm-electric-pole]",
    place_result = "tm-electric-pole",
    stack_size = 50
  },
  {
    type = "electric-pole",
    name = "tm-electric-pole",
    icon = "__base__/graphics/icons/big-electric-pole.png",
    flags = {"placeable-neutral", "player-creation"},
    minable = {hardness = 0.2, mining_time = 0.5, result = "tm-electric-pole"},
    max_health = 150,
    corpse = "medium-remnants",
    resistances = 
    {
      {
        type = "fire",
        percent = 100
      }
    },
    collision_box = {{-0.7, -0.7}, {0.7, 0.7}},
    selection_box = {{-1, -1}, {1, 1}},
    drawing_box = {{-2.8, -0.5}, {0.5, 0.5}},
    maximum_wire_distance = 256,
    supply_area_distance = 16, -- 128
    pictures =
    {
      filename = "__base__/graphics/entity/big-electric-pole/big-electric-pole.png",
      priority = "high",
      width = 168,
      height = 165,
      axially_symmetrical = false,
      direction_count = 4,
      shift = {1.6, -1.1}
    },
    connection_points =
    {
      {
        shadow =
        {
          copper = {2.7, 0},
          green = {1.8, 0},
          red = {3.6, 0}
        },
        wire =
        {
          copper = {0, -3.1},
          green = {-0.6,-3.1},
          red = {0.6,-3.1}
        }
      },
      {
        shadow =
        {
          copper = {3.1, 0.2},
          green = {2.3, -0.3},
          red = {3.8, 0.6}
        },
        wire =
        {
          copper = {-0.08, -3.15},
          green = {-0.55, -3.5},
          red = {0.3, -2.87}
        }
      },
      {
        shadow =
        {
          copper = {2.9, 0.06},
          green = {3.0, -0.6},
          red = {3.0, 0.8}
        },
        wire =
        {
          copper = {-0.1, -3.1},
          green = {-0.1, -3.55},
          red = {-0.1, -2.8}
        }
      },
      {
        shadow =
        {
          copper = {3.1, 0.2},
          green = {3.8, -0.3},
          red = {2.35, 0.6}
        },
        wire =
        {
          copper = {0, -3.25},
          green = {0.45, -3.55},
          red = {-0.54, -3.0}
        }
      }
    },
    copper_wire_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/copper-wire.png",
      priority = "high",
      width = 224,
      height = 46
    },
    green_wire_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/green-wire.png",
      priority = "high",
      width = 224,
      height = 46
    },
    radius_visualisation_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/electric-pole-radius-visualization.png",
      width = 12,
      height = 12
    },
    red_wire_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/red-wire.png",
      priority = "high",
      width = 224,
      height = 46
    },
    wire_shadow_picture =
    {
      filename = "__base__/graphics/entity/small-electric-pole/wire-shadow.png",
      priority = "high",
      width = 224,
      height = 46
    }
  }
}
)