--local RED = {r=1, g=0.5, b=0.5}
--local GREEN = {r=0.5, g=1, b=0.5}
local categories = {
  ["crafting"]=true,
  ["advanced-crafting"]=true,
  ["smelting"]=true,
  ["chemistry"]=true,
  ["crafting-with-fluid"]=true,
  ["oil-processing"]=true
}

local function clearinvs(element)
  --game.get_player(index).get_inventory(defines.inventory.playerquickbar).clear()
  game.get_player(element.player_index).get_inventory(defines.inventory.player_main).clear()
  --game.get_player(index).get_inventory(defines.inventory.playerguns).clear()
  --game.get_player(index).get_inventory(defines.inventory.playertools).clear()
  --game.get_player(index).get_inventory(defines.inventory.playerammo).clear()
  --game.get_player(index).get_inventory(defines.inventory.playerarmor).clear()
end

local function make_placeholder(element,count)
  for i=1,count do
    element.add({ type="label", caption="" })
  end
end

local function clear_rightside(player)
  local tmgui = player.gui.top.tm_flow
  if tmgui.tmframe.settings_t then tmgui.tmframe.settings_t.destroy()
  elseif tmgui.tmframe.tools_t then tmgui.tmframe.tools_t.destroy()
  elseif tmgui.tmframe.iflow then tmgui.tmframe.iflow.destroy()
  elseif tmgui.tmframe.playerlist then tmgui.tmframe.playerlist.destroy()
  elseif tmgui.tmframe.warplist then tmgui.tmframe.warplist.destroy() end
end

local function updateDiodes(player)
  local tmgui = player.gui.top.tm_flow
  if tmgui.toolbar and tmgui.toolbar.tl1 then
    tmgui.toolbar.tool__filler.state = ("filler"==global.toolmode[player.name])
    tmgui.toolbar.tool__resource.state = ("resource"==global.toolmode[player.name])
    tmgui.toolbar.tool__selection.state = ("selection"==global.toolmode[player.name])
    tmgui.toolbar.tool__teleport.state = ("teleport"==global.toolmode[player.name])
  end

  if tmgui.tmframe and tmgui.tmframe.tools_t then
    tmgui = tmgui.tmframe.tools_t
    tmgui.filler_options.active_flow.tool__filler.state = ("filler"==global.toolmode[player.name])
    tmgui.resource_options.active_flow.tool__resource.state = ("resource"==global.toolmode[player.name])
    tmgui.selection_options.active_flow.tool__selection.state = ("selection"==global.toolmode[player.name])
    tmgui.teleport_options.active_flow.tool__teleport.state = ("teleport"==global.toolmode[player.name])
  end
end

local function show_toolbar(player)  
  local tmgui = player.gui.top.tm_flow
  if tmgui.toolbar.tl1 then
    tmgui.toolbar.tl1.destroy()
    tmgui.toolbar.tool__resource.destroy()
    tmgui.toolbar.tl2.destroy()
    tmgui.toolbar.tool__teleport.destroy()
    tmgui.toolbar.tl3.destroy()
    tmgui.toolbar.tool__selection.destroy()
    tmgui.toolbar.tl4.destroy()
    tmgui.toolbar.tool__filler.destroy()
  else
    tmgui.toolbar.add({ type="label", name="tl1", caption={"test-mode.tool-filler"} })
    tmgui.toolbar.add({ type="checkbox", name="tool__filler", state=("filler"==global.toolmode[player.name]) })
    tmgui.toolbar.add({ type="label", name="tl2", caption={"test-mode.tool-resource"} })
    tmgui.toolbar.add({ type="checkbox", name="tool__resource", state=("resource"==global.toolmode[player.name]) })
    tmgui.toolbar.add({ type="label", name="tl3", caption={"test-mode.tool-selection"} })
    tmgui.toolbar.add({ type="checkbox", name="tool__selection", state=("selection"==global.toolmode[player.name]) })
    tmgui.toolbar.add({ type="label", name="tl4", caption={"test-mode.tool-teleport"} })
    tmgui.toolbar.add({ type="checkbox", name="tool__teleport", state=("teleport"==global.toolmode[player.name]) })
  end
end

local function show_settings(element)
  local index = type(element)=="table" and element.player_index or element
  local you = game.get_player(index)
  clear_rightside(you)
  local tmgui = you.gui.top.tm_flow.tmframe
  tmgui = tmgui.add({ type="frame", name="settings_t", direction="horizontal", caption={"test-mode.tab1"} })
  
  --tmgui.add({ type="label", caption="|" })
  --make_placeholder(tmgui, 3)
  tmgui.add({ type="frame", name="build_options", direction="vertical", caption={"test-mode.build-options"} })
    tmgui.build_options.add({ type="flow", name="restore_flow", direction="horizontal" })
      tmgui.build_options.restore_flow.add({ type="label", caption={"test-mode.item-restore"} })
      tmgui.build_options.restore_flow.add({ type="checkbox", name="restoretoggle", state = global.build_options[you.name][1] })
    tmgui.build_options.add({ type="flow", name="destructible_flow", direction="horizontal" })
      tmgui.build_options.destructible_flow.add({ type="label", caption={"test-mode.destructible"} })
      tmgui.build_options.destructible_flow.add({ type="checkbox", name="destructibletoggle", state = global.build_options[you.name][2] })
    tmgui.build_options.add({ type="flow", name="minable_flow", direction="horizontal" })
      tmgui.build_options.minable_flow.add({ type="label", caption={"test-mode.minable"} })
      tmgui.build_options.minable_flow.add({ type="checkbox", name="minabletoggle", state = global.build_options[you.name][3] })
    tmgui.build_options.add({ type="flow", name="operable_flow", direction="horizontal" })
      tmgui.build_options.operable_flow.add({ type="label", caption={"test-mode.operable"} })
      tmgui.build_options.operable_flow.add({ type="checkbox", name="operabletoggle", state = global.build_options[you.name][4] })
    tmgui.build_options.add({ type="flow", name="rotatable_flow", direction="horizontal" })
      tmgui.build_options.rotatable_flow.add({ type="label", caption={"test-mode.rotatable"} })
      tmgui.build_options.rotatable_flow.add({ type="checkbox", name="rotatabletoggle", state = global.build_options[you.name][5] })
    tmgui.build_options.add({ type="frame", name="forceselector", caption = {"test-mode.force",  global.build_options[you.name][6]}, style="tm-dropdown-frame", direction="vertical" })

  tmgui.add({ type="frame", name="char_options", direction="vertical", caption={"test-mode.char-options"} })
    tmgui.char_options.add({ type="button", name="getalltech", caption={"test-mode.all-tech"}, style="tm-settings-button" })
    tmgui.char_options.add({ type="button", name="god_mode", caption={"test-mode.god-mode"}, style="tm-settings-button" })

  tmgui.add({ type="frame", name="event_options", direction="vertical", caption={"test-mode.event-options"} })
    tmgui.event_options.add({ type="flow", name="print_flow", direction="horizontal" })
      tmgui.event_options.print_flow.add({ type="label", caption={"test-mode.print-events"} })
      tmgui.event_options.print_flow.add({ type="checkbox", name="eventtoggle", state = global.event_options[you.name][1] })
    tmgui.event_options.add({ type="flow", name="chunk_flow", direction="horizontal" })
      tmgui.event_options.chunk_flow.add({ type="label", caption={"test-mode.ignore-chunks"} })
      tmgui.event_options.chunk_flow.add({ type="checkbox", name="chunktoggle", state = not global.event_options[you.name][2] })

  tmgui.add({ type="frame", name="world_options", direction="vertical", caption={"test-mode.world-options"} })
    tmgui.world_options.add({ type="button", name="killallenemies", caption = {"test-mode.killallenemies"}, style = "tm-settings-button" })
    tmgui.world_options.add({ type="flow", name="peace_flow", direction="horizontal" })
      tmgui.world_options.peace_flow.add({ type="label", caption={"test-mode.peacefulmode"} })
      tmgui.world_options.peace_flow.add({ type="checkbox", name="peacetoggle", state = game.peaceful_mode })
    tmgui.world_options.add({ type="flow", name="time_flow", direction="horizontal" })
      tmgui.world_options.time_flow.add({ type="label", caption={"test-mode.time-of-day"} })
      tmgui.world_options.time_flow.add({ type="button", name="timetoggle", caption = {global.world_options[1]}, style = "tm-settings-button" })
    --tmgui.world_options.add({ type="flow", name="save_flow", direction="horizontal" })
      --tmgui.world_options.save_flow.add({ type="textfield", name="path_box", caption="scenario" })
      --tmgui.world_options.save_flow.add({ type="button", name="savescenario", caption = {"test-mode.savescenario"}, style = "tm-settings-button" })

  global.tab_active[you.name] = "settings"
end

local function findEntityPrototypes(typename)
  local tbl = {}
  for name, prototype in pairs(game.entity_prototypes) do
    if prototype.type == typename then
      tbl[#tbl+1] = name
    end
  end
  table.sort(tbl)
  return tbl
end

local function show_tool_settings(element)
  local resources = findEntityPrototypes("resource")
  local index = type(element)=="table" and element.player_index or element
  local you = game.get_player(index)
  clear_rightside(you)
  local tmgui = you.gui.top.tm_flow

  tmgui = tmgui.tmframe.add({ type="frame", name="tools_t", direction="horizontal", caption={"test-mode.tool-modes"} })
  --tmgui.add({ type="label", caption={"test-mode.tool-modes"} })
  --make_placeholder(tmgui, 7)
    tmgui.add({ type="frame", name="filler_options", direction="vertical", caption={"test-mode.tool-filler"} })
      tmgui.filler_options.add({ type="flow", name="active_flow", direction="horizontal" })
        tmgui.filler_options.active_flow.add({ type="label", caption={"test-mode.active"} })
        tmgui.filler_options.active_flow.add({ type="checkbox", name="tool__filler", state=("filler"==global.toolmode[you.name]) })
      tmgui.filler_options.add({ type="label", name="lastitem_label", caption={"test-mode.last-item", global.lastitem[you.name] or "none"} })
      
    tmgui.add({ type="frame", name="resource_options", direction="vertical", caption={"test-mode.tool-resource"} })
      tmgui.resource_options.add({ type="flow", name="active_flow", direction="horizontal" })
        tmgui.resource_options.active_flow.add({ type="label", caption={"test-mode.active"} })
        tmgui.resource_options.active_flow.add({ type="checkbox", name="tool__resource", state=("resource"==global.toolmode[you.name]) })
    local key
    for i=1, #resources do
      if string.find(resources[i], "__tm", 1, true) == nil then
        key = "resource_"..i.."_flow"
        tmgui.resource_options.add({ type="flow", name=key, direction="horizontal" })
          tmgui.resource_options[key].add({ type="label", caption= game.entity_prototypes[resources[i]].localised_name })
          tmgui.resource_options[key].add({ type="checkbox", name="resource__"..resources[i], state=(resources[i]==global.resource[you.name]) })
      end
    end
    
    tmgui.add({ type="frame", name="selection_options", direction="vertical", caption={"test-mode.tool-selection"} })
      tmgui.selection_options.add({ type="flow", name="active_flow", direction="horizontal" })
        tmgui.selection_options.active_flow.add({ type="label", caption={"test-mode.active"} })
        tmgui.selection_options.active_flow.add({ type="checkbox", name="tool__selection", state=("selection"==global.toolmode[you.name]) })
    
    tmgui.add({ type="frame", name="teleport_options", direction="vertical", caption={"test-mode.tool-teleport"} })
      tmgui.teleport_options.add({ type="flow", name="active_flow", direction="horizontal" })
        tmgui.teleport_options.active_flow.add({ type="label", caption={"test-mode.active"} })
        tmgui.teleport_options.active_flow.add({ type="checkbox", name="tool__teleport", state=("teleport"==global.toolmode[you.name]) })

  --tmgui.add({ type="label", caption={"test-mode.tool-teleport-avoid"} })--TELE
  --tmgui.add({ type="checkbox", name="avoid", state=global.teleport[you.name].avoid })--TELE

  tmgui.add({ type="button", name="spawn_tool", caption={"test-mode.tool-spawn"} })
  tmgui.add({ type="button", name="toolbar_b", caption={"test-mode.show-toolbar"} })

  global.tab_active[you.name] = "tools"
end

local function findAndSortGroupnames()
  -- Collect groups names
  local groups = {}
  for k,v in pairs(game.item_prototypes) do
  
    groups[v.group.name] = true
  end
  -- Move to array
  local array = {}
  for k, v in pairs(groups) do
    array[#array + 1] = k
  end
  -- Return sorted array
  table.sort(array)
  return array
end

local function add_groups(element)
  local groups = findAndSortGroupnames()
  --local shortname
  -- Create gui buttons
  local arrows = #groups > SHOW_GROUPS
  if arrows then
    element.add({ type="button", name="tab__<", caption="<" })
  end
  for i=1, ( arrows and SHOW_GROUPS or #groups ) do
    --shortname = #groups[i] < 15 and groups[i] or string.sub(groups[i])
    element.add({ type="button", name="tab__" .. groups[i], caption=groups[i] })
  end
  if arrows then
    element.add({ type="button", name="tab__>", caption=">" })
  end
end

local function scroll_groups(element)
  local groups = findAndSortGroupnames()
  local grouptabs = element.gui.top.tm_flow.tmframe.iflow.tabs
  local elementlist = grouptabs.children_names
  local visibletabs = {}
  local recreatetabs = false
  for i=3, #elementlist - 1 do
    _, _, visibletabs[#visibletabs+1] = elementlist[i]:find("tab__(.+)")
  end

  if element.name == "tab__<" then -- Left button causes elements to move right
    if visibletabs[1] == groups[1] then return end

    for i=2, #groups do
      if visibletabs[1] == groups[i] then
      
        for j=3, #elementlist do
          grouptabs[elementlist[j]].destroy()
        end
        
        table.remove(visibletabs)
        table.insert(visibletabs, 1,groups[i-1])
        recreatetabs = true
        break
      end
    end

  else -- elements move to left
    if visibletabs[#visibletabs] == groups[#groups] then return end

    for i=#groups-1, 1, -1 do
      if visibletabs[#visibletabs] == groups[i] then
      
        for j=3, #elementlist do
          if grouptabs[elementlist[j]] then grouptabs[elementlist[j]].destroy() end
        end
        
        table.remove(visibletabs, 1)
        table.insert(visibletabs, groups[i+1])
        recreatetabs = true
        break
      end
    end
    
  end
  -- Recreate tabs
  if recreatetabs then
    for i=1, #visibletabs do
      grouptabs.add({ type="button", name="tab__" .. visibletabs[i], caption=visibletabs[i] })
    end
    grouptabs.add({ type="button", name="tab__>", caption=">" })
  end
end

local function addItemButton(element, ingredient, action)
  local itemname = ingredient.name or ingredient
  local name = action.."__" .. itemname
  if itemname and not element[name] then
    local ok, err = pcall(function()
      element.add({ type="checkbox", name=name, style="tm-icon-"..itemname, state = true })
    end)

    -- [[
    if not ok then
      game.get_player(element.player_index).print(err)
      if element[name] then
        element[name].destroy()
      end
      element.add({ type="button", name=name,
                    style="tm-item-button",
                    caption =  game.item_prototypes[itemname].localised_name })
    end
    --]]
  end
end

local function addItemButton2(element, action, itemname, amount)
    local name = action.."__" .. itemname
  if itemname and not element[name] then
    local ok, err = pcall(function()
      element.add({ type="frame", name=name, caption = not amount and "0" or amount,
                    style="tm-icon-frame-"..itemname })
    end)
    
    -- [[
    if not ok then
      game.get_player(element.player_index).print(err)
      if element[name] then
        element[name].destroy()
      end
      element.add({ type="button", name=name,
                    style="tm-item-button",
                    caption = game.item_prototypes[itemname].localised_name })

    end
    --]]
  end
end

local function add_footer(element)
  if element.footer then element.footer.destroy() end
  element.add({ type="flow", name="footer", direction="horizontal" })
  make_placeholder(element.footer,1)
  element.footer.add({ type="button", name="clearall", caption={"test-mode.clear-inv"} })
end

local function add_itemlist(element, typename)
  local index = type(element)~="table" and element or element.player_index
  local you = game.get_player(index)
  global.active_group[you.name] = typename
  local tmgui = you.gui.top.tm_flow
  if tmgui.tmframe.iflow.itemlist_t and tmgui.tmframe.iflow.itemlist_t.valid then
    tmgui.tmframe.iflow.itemlist_t.destroy()
  end
  tmgui.tmframe.iflow.add({ type="table", name="itemlist_t", colspan=ITEM_COLSPAN })

  local items = {}
  for k,v in pairs(game.item_prototypes) do
    if v.group.name == typename then
      table.insert(items, v.name)
    end
  end

  table.sort(items)--, function(a,b) return game.get_localised_item_name(a)[1] < game.get_localised_item_name(b)[1] end)
  for _, name in ipairs(items) do
    addItemButton(tmgui.tmframe.iflow.itemlist_t, name, "insert")
  end

  add_footer(tmgui.tmframe.iflow)
end

local function showItemSearch(key, index)
  local you = game.get_player(index)
  local tmgui = you.gui.top.tm_flow
  if tmgui.tmframe.iflow.itemlist_t and tmgui.tmframe.iflow.itemlist_t.valid then
    tmgui.tmframe.iflow.itemlist_t.destroy()
  end
  tmgui.tmframe.iflow.add({ type="table", name="itemlist_t", colspan=ITEM_COLSPAN })

  local items = {}
  key = key:lower()
  for _,v in pairs(game.item_prototypes) do
    if game.item_prototypes[v.name].localised_name[1]:lower():find(key, 1, true) then
      table.insert(items, v.name)
    end
  end

  table.sort(items)--, function(a,b) return game.get_localised_item_name(a)[1] < game.get_localised_item_name(b)[1] end)
  for _, name in ipairs(items) do
    addItemButton(tmgui.tmframe.iflow.itemlist_t, name, "insert")
  end

  add_footer(tmgui.tmframe.iflow)
end

local function show_items(element)
  local index = type(element)=="table" and element.player_index or element
  local you = game.get_player(index)
  local tmgui = you.gui.top.tm_flow
  clear_rightside(you)
  tmgui.tmframe.add({ type="flow", name="iflow", direction="vertical" })
  tmgui.tmframe.iflow.add({ type="flow", name="tabs", direction="horizontal" })
  tmgui.tmframe.iflow.tabs.add({ type="label", caption={"test-mode.item-types"} })
  add_groups(tmgui.tmframe.iflow.tabs)
  tmgui.tmframe.iflow.add({ type="flow", name="sflow", direction="horizontal" })
  tmgui.tmframe.iflow.sflow.add({ type="label", caption={"test-mode.search"} })
  tmgui.tmframe.iflow.sflow.add({ type="textfield", name="search_box", style="number_textfield_style", text = "----" })
  if global.active_searches[you.name] and type(global.active_searches[you.name][2]) == "string"
     and global.active_searches[you.name][2] ~= "" then
    showItemSearch( global.active_searches[you.name][2], index )
  elseif global.active_group[you.name] then
    add_itemlist( index, global.active_group[you.name] )
  else -- empty list
    tmgui.tmframe.iflow.add({ type="table", name="itemlist_t", colspan=ITEM_COLSPAN })
    make_placeholder(tmgui.tmframe.iflow.itemlist_t,1)
    add_footer(tmgui.tmframe.iflow)
  end
  global.tab_active[you.name] = "items"
end

local function show_players(element)
  local index = type(element)=="table" and element.player_index or element
  local you = game.get_player(index)
  local tmgui = you.gui.top.tm_flow
  clear_rightside(you)
  tmgui = tmgui.tmframe.add({ type="flow", name="playerlist", direction="vertical" })
  local pframe
  for i, p in pairs(game.players) do
    pframe = tmgui.add({ type="frame", name="player"..i, direction="horizontal" })
    pframe.add({ type = "label", name = "pindex", caption = i })
    if i == index then
      pframe.add({ type = "label", name = "pname", caption = p.name })
      pframe.add({ type = "textfield", name = "p_rgba" }).text = table.concat({"r=",round(p.color.r * 100, 2),", g=",round(p.color.g * 100, 2),", b=",round(p.color.b * 100, 2),", a=",round(p.color.a * 100, 2)})
      pframe.add({ type = "button", name = "setcolor", caption = {"test-mode.set"} })
    else
      pframe.add({ type = "label", name = "pname", caption = p.name })
      pframe.add({ type = "label", name = "pcolor", caption = table.concat({"{r=",round(p.color.r * 100, 2),", g=",round(p.color.g * 100, 2),", b=",round(p.color.b * 100, 2),", a=",round(p.color.a * 100, 2),"}"}) })
      pframe.add({ type = "button", name = "warpToP__"..i, caption = {"test-mode.warp"} })
    end
  end 
  
  global.tab_active[you.name] = "players"
end

local function show_warps(element)
  local index = type(element)=="table" and element.player_index or element
  local you = game.get_player(index)
  local tmgui = you.gui.top.tm_flow
  clear_rightside(you)
  tmgui = tmgui.tmframe.add({ type="flow", name="warplist", direction="vertical" })
  local pframe
  for i, warp in pairs(global.warps) do
    pframe = tmgui.add({ type="frame", name="warp"..i, direction="horizontal" })
    pframe.add({ type = "label", name = "windex", caption = i })
    pframe.add({ type = "label", name = "wname", caption = warp.name })
    pframe.add({ type = "label", name = "w_x", caption = warp.x })
    pframe.add({ type = "label", name = "w_y", caption = warp.y })
    pframe.add({ type = "button", name = "warp__"..i, caption = {"test-mode.warp"} })
    pframe.add({ type = "button", name = "removewarp__"..i, caption = {"test-mode.remove"} })
  end 
    pframe = tmgui.add({ type="frame", name="warp"..(#global.warps+1), direction="horizontal" })
    pframe.add({ type = "label", name = "wnumber", caption = (#global.warps+1) })
    pframe.add({ type = "textfield", name = "wname" }).text = "Warp "..(#global.warps+1)
    pframe.add({ type = "textfield", name = "w_x" }).text = round(you.position.x, 5)
    pframe.add({ type = "textfield", name = "w_y" }).text = round(you.position.y, 5)
    pframe.add({ type = "button", name = "newwarp__"..(#global.warps+1), caption = {"test-mode.create"} })
    
    global.tab_active[you.name] = "warps"
end

local function tm_toggle(element)
  local index = type(element)=="table" and element.player_index or element
  local player = game.get_player(index)
  local tmgui = player.gui.top.tm_flow
  if tmgui.tmframe then
    tmgui.tmframe.destroy()
    tmgui.toolbar.tm_b.destroy()
    tmgui.toolbar.add({ type="button", name="tm_b", caption={"test-mode.name"} })
    if tmgui.toolbar.tl1 then
      show_toolbar(player)
      show_toolbar(player) --Fixing element order
    end
  else
    tmgui.add({ type="frame",direction="horizontal", name="tmframe" }) -- , caption={"test-mode.frametitle"}
    tmgui.tmframe.add({ type="flow", name="maintabs", direction="vertical" })
    tmgui.tmframe.maintabs.style.resize_row_to_width = true
    tmgui.tmframe.maintabs.add({ type="button", name="tm_settings_b", caption={"test-mode.tab1"} })
    tmgui.tmframe.maintabs.add({ type="button", name="tm_tools_b", caption={"test-mode.tab2"} })
    tmgui.tmframe.maintabs.add({ type="button", name="tm_items_b", caption={"test-mode.tab3"} })
    tmgui.tmframe.maintabs.add({ type="button", name="tm_players_b", caption={"test-mode.tab4"} })
    tmgui.tmframe.maintabs.add({ type="button", name="tm_warps_b", caption={"test-mode.tab5"} })
    if global.tab_active[player.name] == "settings" then
      show_settings(index)
    elseif global.tab_active[player.name] == "tools" then
      show_tool_settings(index)
    elseif global.tab_active[player.name] == "items" then
      show_items(index)
    elseif global.tab_active[player.name] == "players" then
      show_players(index)
    elseif global.tab_active[player.name] == "warps" then
      show_warps(index)
    end
  end
end

local function fillGUI(player)
  player.gui.center.add({ type="frame", direction="horizontal", name="popup", caption = {"test-mode.popup-filler"} })
  player.gui.center.popup.add({ type="table", name="tbl", colspan=2 })
  local guitbl = player.gui.center.popup.tbl
  guitbl.add({ type="label", caption={"test-mode.auto-refill"} })
  guitbl.add({ type="checkbox", name="autorefill", state=false })
  
  guitbl.add({ type="button", name="fill__iron-ore", style="tm-item-button", caption = game.item_prototypes["iron-ore"].localised_name })
  guitbl.add({ type="button", name="fill__iron-plate", style="tm-item-button", caption = game.item_prototypes["iron-plate"].localised_name })
  
  guitbl.add({ type="button", name="fill__steel-plate", style="tm-item-button", caption = game.item_prototypes["steel-plate"].localised_name })
  guitbl.add({ type="button", name="fill__coal", style="tm-item-button", caption = game.item_prototypes["coal"].localised_name })
	
  guitbl.add({ type="button", name="fill__copper-ore", style="tm-item-button", caption = game.item_prototypes["copper-ore"].localised_name })
  guitbl.add({ type="button", name="fill__copper-plate", style="tm-item-button", caption = game.item_prototypes["copper-plate"].localised_name })

  guitbl.add({ type="button", name="fill__stone", style="tm-item-button", caption = game.item_prototypes["stone"].localised_name })
  guitbl.add({ type="button", name="fill__stone-brick", style="tm-item-button", caption = game.item_prototypes["stone-brick"].localised_name })

  guitbl.add({ type="button", name="fill__solid-fuel", style="tm-item-button", caption = game.item_prototypes["solid-fuel"].localised_name })
  guitbl.add({ type="button", name="fill__lastused", style="tm-item-button", caption = {"test-mode.popup-last-item"} })
  
  guitbl.add({ type="button", name="fill__list", style="tm-item-button", caption = {"test-mode.popup-select"} })
  guitbl.add({ type="button", name="fill__clear", style="tm-item-button", caption = {"test-mode.clear"} })
  
  guitbl.add({ type="button", name="fill__cancel", style="tm-item-button", caption = {"test-mode.cancel"} })
end

local function stacksizeGUI(player)
  if not game.item_prototypes[global.itemname[player.name]] then return player.print({"test-mode.cannot-insert", global.itemname[player.name]}) end
  player.gui.center.add({ type="frame", direction="horizontal", name="popup", caption = game.item_prototypes[global.itemname[player.name]].localised_name })
    player.gui.center.popup.add({ type="table", name="tbl", colspan=3 })
  local guitbl = player.gui.center.popup.tbl
  guitbl.add({ type="textfield", name="stacksize-box", style="number_textfield_style", text = "1" }).text = "1"
  guitbl.add({ type="button", name="stacksize__items", style="tm-popup-button", caption = {"test-mode.items"} })
  guitbl.add({ type="button", name="stacksize__stacks", style="tm-popup-button", caption = {"test-mode.stacks"} })
  guitbl.add({ type="button", name="stacksize__recipeviewer", style="tm-popup-button", caption = {"test-mode.recipeviewer"} })
  guitbl.add({ type="button", name="stacksize__cancel", style="tm-popup-button", caption = {"test-mode.cancel"} })
end

local function selectionpromptGUI(player, a, b)
  player.gui.center.add({ type="frame", direction="vertical", name="popup",
    caption = {"test-mode.popup-selection", round(a[1],1), round(a[2],1), round(b[1],1), round(b[2],1)}
  })
  local popup = player.gui.center.popup
  popup.add({ type="table", name="tbl", colspan=6 })

  local names = {}
  for i,entity in ipairs(global.selectables[player.name]) do
    if entity.valid and entity.name then
      if names[entity.name] == nil then
        names[entity.name] = 1
      else
        names[entity.name] = names[entity.name] + 1
      end
    end
  end

  for name, count in pairs(names) do
    popup.tbl.add({ type = "label", caption = name .. ": " .. count })
    popup.tbl.add({ type="checkbox", name="selected__" .. name, state = false })
  end
  
  make_placeholder(popup, 1)
  popup.add({ type="flow", direction="horizontal", name="footer" })
  popup.footer.add({ type="button", name="selection__cut", style="tm-popup-button", caption = {"test-mode.cut"} })
  popup.footer.add({ type="button", name="selection__copy", style="tm-popup-button", caption = {"test-mode.copy"} })
  popup.footer.add({ type="button", name="selection__paste", style="tm-popup-button", caption = {"test-mode.paste"} })
  popup.footer.add({ type="button", name="selection__pattern", style="tm-popup-button", caption = {"test-mode.pattern"} })
  popup.footer.add({ type="button", name="selection__remove", style="tm-popup-button", caption = {"test-mode.remove"} })
  popup.footer.add({ type="button", name="selection__cancel", style="tm-popup-button", caption = {"test-mode.cancel"} })
end

local function activationGUI(player)
  local center = player.gui.center
  center.add({ type="frame", direction="horizontal", name="popup", caption = {"test-mode.activate-mod"} })
  center.popup.add({ type="button", name="activate_yes", style="tm-popup-button", caption = {"test-mode.yes"} })
  center.popup.add({ type="button", name="activate_no", style="tm-popup-button", caption = {"test-mode.no"} })
end

local function patternGUI(player)
  local username = player.name
  local size = {width = global.blueprint[username].edges.x.max - global.blueprint[username].edges.x.min,
                height = global.blueprint[username].edges.y.max - global.blueprint[username].edges.y.min} 
  local title = {"test-mode.popup-pattern", round(size.width,1), round(size.height,1)}
  player.gui.center.add({ type="frame", direction="vertical", name="popup", caption = title })
  player.gui.center.popup.add({ type="table", name="tbl", colspan=6 })
  local guitbl = player.gui.center.popup.tbl
-- Row 1
  guitbl.add({ type="label", caption="Repeat" })
  guitbl.add({ type="label", caption="counts" })
  make_placeholder(guitbl, 2)
  guitbl.add({ type="label", caption="Gap widths" })
  guitbl.add({ type="label", caption="(in tiles)" })
-- Row 2
  guitbl.add({ type="textfield", name="pattern-left", style="number_textfield_style", text = "0" }).text = 0
  guitbl.add({ type="label", caption="Left " })
  guitbl.add({ type="textfield", name="pattern-right", style="number_textfield_style", text = "0" }).text = 0
  guitbl.add({ type="label", caption="Right " })
  guitbl.add({ type="textfield", name="pattern-gaps-x", style="number_textfield_style", text = "1" }).text = 1
  guitbl.add({ type="label", caption="in X-axis" })
-- Row 3
  guitbl.add({ type="textfield", name="pattern-up", style="number_textfield_style", text = "0" }).text = 0
  guitbl.add({ type="label", caption="Up " })
  guitbl.add({ type="textfield", name="pattern-down", style="number_textfield_style", text = "0" }).text = 0
  guitbl.add({ type="label", caption="Down " })
  guitbl.add({ type="textfield", name="pattern-gaps-y", style="number_textfield_style", text = "1" }).text = 1
  guitbl.add({ type="label", caption="in Y-axis" })
----
  player.gui.center.popup.add({ type="flow", direction="horizontal", name="footer" })
  player.gui.center.popup.footer.add({ type="button", name="pattern__create", style="tm-popup-button", caption = {"test-mode.create"} })
  player.gui.center.popup.footer.add({ type="button", name="pattern__cancel", style="tm-popup-button", caption = {"test-mode.cancel"} })
end

function centerPopUp(action, player, a, b)
  if player.gui.center.popup ~= nil then -- old popup need to be removed first
    if action == "clear" then
      player.gui.center.popup.destroy() -- recreating and removing to make sure no invisible element is left behind.
      player.gui.center.add({ type="flow", direction="horizontal", name="popup" })
      player.gui.center.popup.destroy()
    elseif action == "insertion" and player.gui.center.popup.left then -- allow user to pick items from itemlist to view in ingredient/product viewer.
      centerPopUp("clear", player)
      recipeviewerGUI(player, a, 1)
    end
  elseif action == "fill" then -- ask items used in filling
    fillGUI(player)
  elseif action == "insertion" then -- ask stacksize to be used in insertion
    global.itemname[player.name] = a
    stacksizeGUI(player)
  elseif action == "selection" then -- show selected entities and ask course of action
    selectionpromptGUI(player, a,b)
  elseif action == "pattern" then
    patternGUI(player)
  elseif action == "activation" then
    activationGUI(player)
  end
end

local function fillEntities(entities, itemname)
  if itemname == "clear" then
    for i=1, #entities do
      if entities[i].valid and entities[i].type ~= "player" then
        entities[i].clear_items_inside()
      end
    end
  else
    for i=1, #entities do
      if entities[i].valid and entities[i].type ~= "player" then
        entities[i].insert({name = itemname, count = game.item_prototypes[itemname].stack_size * BIGGEST_INV})
      end
    end
  end
end

local function insert(element, itemname)
  element.state = true
  local index = element.player_index
  local player = game.get_player(index)
  if global.fillselected[player.name] == nil then -- No selection to fill. 
    return centerPopUp("insertion", player, itemname) --stacksize question popup.
  elseif global.fillselected[player.name] then -- Filling selection. Item picked from list.
    if global.fillselected[player.name].autorefill == true then
      global.auto_refill_list[#global.auto_refill_list + 1] = {global.fillselected[player.name], itemname}
    else
      fillEntities(global.fillselected[player.name], itemname)
    end
    global.lastitem[player.name] = itemname
    global.fillselected[player.name] = nil

    if player.gui.top.tm_flow.tmframe then tm_toggle(index) end
  end
end

local function findRecipes(itemname, isproduct)
  local temp
  local recipes = {}
  if isproduct then
    for _ ,recipe in pairs(game.forces.player.recipes) do
      temp = recipe.products
      for i=1, #temp do
        if temp[i].name == itemname then
          recipes[#recipes + 1] = recipe
          --return recipes, temp[i].amount
          break
        end
      end
    end
    
  else -- not product
    for _ ,recipe in pairs(game.forces.player.recipes) do
      temp = recipe.ingredients
      for i=1, #temp do
        if temp[i].name == itemname then
          recipes[#recipes + 1] = recipe
          break
        end
      end
    end
  end
  
  return recipes
end

local function addRecipeFrame(element, amount, product, recipename)
  local player = game.get_player(element.player_index)
  --player.print("Element: "..element.name..". Amount: "..tostring(amount)..". Product: "..tostring(product)..". Recipename: "..tostring(recipename))
  local recipe
  local recipies
  if recipename then
    recipe = player.force.recipes[recipename]
    if not recipe then
      return player.print( "bad recipename" )
    end
  else
    recipies = findRecipes(product, true)
    recipe = recipies[1]
  end
  
  if recipename or #recipies == 1 then
    local category = categories[recipe.category] and recipe.category or "unknown"
    local factor  --amount is item count and factor is recipe count
    local frame
    local holestyle
    local style = "tm-recipe-"..category
    
    for i=1, # recipe.products do
      if recipe.products[i].name == product then
        factor = math.ceil( amount / recipe.products[i].amount )
      end
    end
    
    if element.name == "popup" then
      frame = element.add({ type="frame", direction="horizontal", name="recipe__".. product.."_"..amount, style=style,
                            caption={"test-mode.recipe-caption", recipe.name, factor} })
      holestyle = "tm-recipe-unknown-hole"
    else
      frame = element.parent
      --amount = tonumber(element.caption) or tonumber(frame.name)
      local temp = frame.parent.parent.style.name
      holestyle = not temp and "tm-recipe-unknown-hole" or temp .. "-hole"
      
      frame.style = style
      frame.caption = {"test-mode.recipe-caption", recipe.name, factor}--------------------------------
      local list = frame.children_names
      for i=1, #list do
        frame[list[i]].destroy()
      end
    end
    
    frame.add({ type="flow", direction="vertical", name="products" })
    frame.add({ type="flow", direction="vertical", name="ingredients" })
      
    local framehole
    for k=1, # recipe.products do
      if holestyle and recipe.products[k].name == product then
        framehole = frame.products.add({type="frame", style=holestyle})
        addItemButton2(framehole, "ingredient", recipe.products[k].name, recipe.products[k].amount * factor)
      else
        addItemButton2(frame.products, "ingredient", recipe.products[k].name, recipe.products[k].amount * factor)
      end
    end

    for k=1, # recipe.ingredients do
      addItemButton2( frame.ingredients.add({type="frame", style=style, name="recipe__"..recipe.ingredients[k].name.."_"..recipe.ingredients[k].amount * factor}),
                      "openingredient", recipe.ingredients[k].name, recipe.ingredients[k].amount * factor )
    end
    
  elseif #recipies > 1 then
    player.print( "multiple recipies" )
    local frame
    if element.name == "popup" then
      frame = element.add({ type="frame", direction="vertical", name="recipe__"..product.."_"..amount, style="tm-recipe-unknown" })
    else
      frame = element.parent
      frame.style = "tm-recipe-unknown"
      
      local list = frame.children_names
      for i=1, #list do
        frame[list[i]].destroy()
      end
    end
    
    for i=1, #recipies do
      frame.add({ type="button", name="openrecipe__"..recipies[i].name, caption=recipies[i].name, style = "tm-settings-button" })
    end
  else
    player.print( {"test-mode.no-recipe", product} )
  end
  
end

local function addProductTable(element, amount, itemname, recipies)
  if recipies == nil then
    recipies = findRecipes(itemname, false)
  end
  
  if #recipies > 0 then
    local productstbl = element.add({ type="table", name="products", colspan= 1 + math.floor(# recipies / 12) })
    for i=1, # recipies do
      for j=1, # recipies[i].products do
        for k=1, # recipies[i].ingredients do  -- getting right amount for rigth ingredient
          if recipies[i].ingredients[k].name == itemname then
            addItemButton2( productstbl, "product", recipies[i].products[j].name,
                            math.floor(recipies[i].products[j].amount * amount / recipies[i].ingredients[k].amount) )
          end
        end
      end
    end
  end
  
end

function recipeviewerGUI(player, itemname, amount)
  global.itemname[player.name] = itemname
  local recipies = findRecipes(itemname, false)
  --Controls (Top left)
  local popup = player.gui.center.add({ type="flow", direction="horizontal", name="popup" })
  popup.add({ type="flow", direction="vertical", name="left" })
    popup.left.add({ type="frame", direction="vertical", name="controls", caption="Controls" })
      popup.left.controls.add({ type="flow", name="line1", direction="horizontal" })
        popup.left.controls.line1.add({ type="button", name="backinsert", style="tm-popup-button", caption = {"test-mode.back"} })
        popup.left.controls.line1.add({ type="button", name="closePopup", style="tm-popup-button", caption = {"test-mode.close"} })
  --Product list (Bottom left)
  if #recipies > 0 then
    addProductTable( popup.left.add( { type="frame", direction="vertical", name="products", caption="Products" } ),
                    amount, itemname, recipies )
  end
  --Recipe tree (Right)
  addRecipeFrame(popup, amount, itemname)
end

local function changeMainProduct(element, itemname)
  local player = game.get_player(element.player_index)
  local i = tonumber(element.caption)
  if i == nil or i < 1 then i = 1 end
  centerPopUp("clear", player)
  recipeviewerGUI(player, itemname, i)
end

local function stacksize(element, action)
  local player = game.get_player(element.player_index)
  local value = tonumber(player.gui.center.popup.tbl["stacksize-box"].text)
  if action == "items" or action == "stacks" then
    if value then
      if action == "stacks" then
        value = value * game.item_prototypes[global.itemname[player.name]].stack_size
      end
      player.insert( {name=global.itemname[player.name], count=value} )
    end
    return centerPopUp("clear", player)
    
  elseif action == "recipeviewer" then
    centerPopUp("clear", player)
    return recipeviewerGUI(player, global.itemname[player.name], value or 1)
    
  elseif action == "cancel" then
    return centerPopUp("clear", player)
  end
end

local function fill(element, name)
  local index = element.player_index
  local player = game.get_player(index)
  if name == "cancel" then -- cancel fill
    global.fillselected[player.name] = nil
  elseif name == "clear" then
    if element.parent.autorefill.state == false then
      fillEntities(global.fillselected[player.name], name)
    else
      global.auto_refill_list[#global.auto_refill_list + 1] = {global.fillselected[player.name], name}
    end
    global.fillselected[player.name] = nil
    
  elseif name == "list" then --call itemlist
    global.tab_active[player.name] = "items"
    global.fillselected[player.name].autorefill = element.parent.autorefill.state
    if player.gui.top.tm_flow.tmframe then tm_toggle(index) end
    tm_toggle(index)
    if global.active_group[player.name] == nil then global.active_group[player.name] = "item" end
    add_itemlist(index, global.active_group[player.name])
    
  elseif name == "lastused" then
    if global.fillselected[player.name] and global.lastitem[player.name] then
      if element.parent.autorefill.state == false then
        fillEntities(global.fillselected[player.name], global.lastitem[player.name])
      else
        global.auto_refill_list[#global.auto_refill_list + 1] = {global.fillselected[player.name], global.lastitem[player.name]}
      end
      global.fillselected[player.name] = nil
    end
    
  else -- shortcut insertion
    if global.fillselected[player.name] then
      if element.parent.autorefill.state == false then
        fillEntities(global.fillselected[player.name], name)
      else
        global.auto_refill_list[#global.auto_refill_list + 1] = {global.fillselected[player.name], name}
      end
      global.lastitem[player.name] = name
      global.fillselected[player.name] = nil
    end
  end
  centerPopUp("clear", player)
end

local function pattern(element, action)
  local player = game.get_player(element.player_index)
  if action == "create" then
    local guitbl = player.gui.center.popup.tbl
    patternPaste({left = -guitbl["pattern-left"].text,
                  right = guitbl["pattern-right"].text,
                  up = -guitbl["pattern-up"].text,
                  down = guitbl["pattern-down"].text,
                  gaps = {x = guitbl["pattern-gaps-x"].text,
                  y = guitbl["pattern-gaps-y"].text},
                  edges = global.blueprint[player.name].edges}, player)
    centerPopUp("clear", player)
  elseif action == "cancel" then
    centerPopUp("clear", player)
  end
end

local function toggle_time(element)
  if global.world_options[1] == "test-mode.normal" then
    global.world_options[1] = "test-mode.day"
    game.always_day = true
  elseif global.world_options[1] == "test-mode.day" then
    global.world_options[1] = "test-mode.night"
    game.daytime = 0.5
  else
    global.world_options[1] = "test-mode.normal"
    game.daytime = 0.75
    game.always_day = false
  end
  
  local tmgui
  for i, player in pairs(game.players) do
    tmgui = player.gui.top.tm_flow
    if tmgui and tmgui.tmframe and tmgui.tmframe.settings_t then
      tmgui.tmframe.settings_t.world_options.time_flow.timetoggle.caption = {global.world_options[1]}
    end
  end
end

--    {  }

name2func  = {
  tm_b = tm_toggle,
  tm_settings_b = show_settings,
  tm_tools_b = show_tool_settings,
  tm_items_b = show_items,
  ["tab__<"] = scroll_groups,
  ["tab__>"] = scroll_groups,
  tm_players_b = show_players,
  tm_warps_b = show_warps,
  toolbar_b = show_toolbar,
  -- Game settings
  restoretoggle = function(element)
    local username = game.get_player(element.player_index).name
    global.build_options[username][1] = not global.build_options[username][1]
    element.state = global.build_options[username][1]
  end,
  destructibletoggle = function(element)
    local username = game.get_player(element.player_index).name
    global.build_options[username][2] = not global.build_options[username][2]
    element.state = global.build_options[username][2]
  end,
  minabletoggle = function(element)
    local username = game.get_player(element.player_index).name
    global.build_options[username][3] = not global.build_options[username][3]
    element.state = global.build_options[username][3]
  end,
  operabletoggle = function(element)
    local username = game.get_player(element.player_index).name
    global.build_options[username][4] = not global.build_options[username][4]
    element.state = global.build_options[username][4]
  end,
  rotatabletoggle = function(element)
    local username = game.get_player(element.player_index).name
    global.build_options[username][5] = not global.build_options[username][5]
    element.state = global.build_options[username][5]
  end,
  forceselector = function(element)
    local children = element.children_names
    
    if #children == 0 then
      for name, _ in pairs(game.forces) do
        element.add({type="button", name="force__"..name, caption=name, style="tm-settings-button"})
      end
      
    else
      for i=1, #children do
        element[children[i]].destroy()
      end
    end
  end,
  force = function(element, name)
    global.build_options[game.get_player(element.player_index).name][6] = name
    show_settings(element)
  end,
  
  eventtoggle = function(element)
    local username = game.get_player(element.player_index).name
    global.event_options[username][1] = not global.event_options[username][1]
    element.state = global.event_options[username][1]
  end,
  chunktoggle = function(element)
    local username = game.get_player(element.player_index).name
    global.event_options[username][2] = not global.event_options[username][2]
    element.state = not global.event_options[username][2]
  end,
  
  killallenemies = function(element) game.forces.enemy.kill_all_units() end,
  peacetoggle = function(element)
    game.peaceful_mode = not game.peaceful_mode
    element.state = game.peaceful_mode
  end,
  timetoggle = toggle_time,
  -- Tool modes
  tool = function(element, action)
    local player = game.get_player(element.player_index)
    global.toolmode[player.name] = action
    updateDiodes(player)
  end,
  --avoid = function(element)
    --global.teleport.avoid = not global.teleport.avoid
    --element.state = global.teleport.avoid
  --end,
  fill = fill,
  resource = function(element, resource)
    global.resource[game.get_player(element.player_index).name] = resource
    show_tool_settings(element)
  end,
  
  clearall = clearinvs,
  god_mode = function(element)
    local player = game.get_player(element.player_index)
    if player.character then
      global.character[player.name] = player.character
      player.character = nil
      --copying items
      local bar, main = global.character[player.name].get_inventory(1), global.character[player.name].get_inventory(2)
      local godbar, godmain = player.get_inventory(1), player.get_inventory(2)
      for i=1, #bar do
        if bar[i].valid_for_read then godbar.insert(bar[i]) end
      end
      for i=1, #main do
        if main[i].valid_for_read then godmain.insert(main[i]) end
      end
    elseif global.character[player.name] then
      player.character = global.character[player.name]
      global.character[player.name] = nil
    end
  end,
  getalltech = function(element) game.get_player(element.player_index).force.research_all_technologies() end,
  --savescenario = function(element) game.save(element.gui.top.tm_flow.tmframe.settings_t.world_options.save_flow.path_box.text) end,
  
  spawn_tool = function(element) game.get_player(element.player_index).insert({name="mjollnir", count=32}) end,
  tab = add_itemlist,
  backinsert = function(element)
    local player = game.get_player(element.player_index)
    centerPopUp("clear", player)
    stacksizeGUI(player)
  end,
  closePopup = function(element) centerPopUp("clear", game.get_player(element.player_index)) end,
  insert = insert,
  openingredient = function(element, itemname)
    local number = tonumber(element.caption) or 0
    addRecipeFrame(element, number, itemname)
  end,
  openrecipe = function(element, recipename)
    local _, _, itemname, amount = element.parent.name:find("recipe__(.+)_(%d+)")
    --game.player.print("Element: "..element.name..". Parent: "..element.parent.name..". Itemname: "..tostring(itemname)..". Amount: "..tostring(amount))
    amount = tonumber(amount) or 0
    addRecipeFrame(element, amount, itemname, recipename)
  end,
  recipe = function(element, recipename) --Clicking recipe frame caption will flip the flow direction
    element.direction = element.direction=="horizontal" and "vertical" or "horizontal"
    element.products.direction = element.products.direction=="horizontal" and "vertical" or "horizontal"
    element.ingredients.direction = element.ingredients.direction=="horizontal" and "vertical" or "horizontal"
    --element.add({type="label", caption=""}).destroy()
  end,
  ingredient = changeMainProduct,
  product = changeMainProduct,
  search_box = function(element)
    local player = game.get_player(element.player_index)
    if global.active_searches[player.name] == nil then 
      global.active_searches[player.name] = {element, ""}
    end
  end,
  stacksize = stacksize,
  selection = function(element, action) -- Action for Selected entities
    handleSelected(action, element.player_index)
  end,
  selected = function(element, name) -- toggle entity selections
    local username = game.get_player(element.player_index).name
    global.selectables[username].bools[name] = not global.selectables[username].bools[name]
  end,
  pattern = pattern,
  
  --game.player.gui.top.tm_flow.tmframe.playerlist.player1
  setcolor=function(element)
    element = element.gui.top.tm_flow.tmframe.playerlist["player"..element.player_index]
    local _, _, r, g, b, a = string.find(element.p_rgba.text, "r%s-=%s-(%d+),%s-g%s-=%s-(%d+),%s-b%s-=%s-(%d+),%s-a%s-=%s-(%d+)")
    if not (r and g and b and a) then
      game.get_player(element.player_index).print( table.concat({"Bad input ", tostring(r), tostring(g), tostring(b), tostring(a)}, " ") )
    else
      game.get_player(element.player_index).color = {r=tonumber(r)/100, g=tonumber(g)/100, b=tonumber(b)/100, a=tonumber(a)/100}
    end
  end,
  warpToP=function(element, index)
    index = tonumber(index)
    local surface = game.get_surface(1)
    local wpos = surface.find_non_colliding_position("player", game.get_player(index).position, 10, 0.5)
    if wpos then
      game.get_player(element.player_index).teleport(wpos)
    end
  end,
--game.player.gui.top.tm_flow.tmframe.warplist.warp1
  newwarp=function(element, index)
    element = element.gui.top.tm_flow.tmframe.warplist["warp"..index]
    global.warps[#global.warps+1] = {name=element.wname.text, x=element.w_x.text, y=element.w_y.text}
    show_warps(element.player_index)
  end,
  removewarp=function(element, index)
    element = element.gui.top.tm_flow.tmframe.warplist["warp"..index]
    index = tonumber(index)
    table.remove(global.warps, index)
    show_warps(element.player_index)
  end,
  warp=function(element, index)
    index = tonumber(index)
    local surface = game.get_surface(1)
    local wpos = surface.find_non_colliding_position( "player", {x=global.warps[index].x, y=global.warps[index].y}, 10, 0.5 )
    if wpos then
      game.get_player(element.player_index).teleport(wpos)
    end
  end,
  
  activate_yes = function(element)
    local player = game.get_player(element.player_index)
    activate(player)
    centerPopUp("clear", player)
  end,
  activate_no = function(element)
    local player = game.get_player(element.player_index)
    global.active[player.name] = false
    centerPopUp("clear", player)
  end,
}

return { addItemlist = add_itemlist, showItemSearch = showItemSearch }