--global variables
BIGGEST_INV = 60
ITEM_COLSPAN = 20
SHOW_GROUPS = 5

MOD = { NAME = {"test-mode.name"}, IF = "testmode", LOG = nil }

require "defines"
require "util"
local gui = require "gui"

is_fillable = {
  ["boiler"]=true,
  ["burner-inserter"]=true,
  ["burner-mining-drill"]=true,
  ["car"]=true,
  ["cargo-wagon"]=true,
  ["container"]=true,
  ["furnace"]=true,
  ["locomotive"]=true,
  ["logistic-container"]=true,
  ["rocket-silo-rocket"]=true
}

--
-- Script Events
--

script.on_configuration_changed(function(data)
  if data.mod_changes and data.mod_changes["test-mode"] then
    initglobal()
  end
  if MOD.LOG then
    MOD.LOG = MOD.LOG .. game.tick .. ": on_configuration_changed\n"
    --MOD.LOG = MOD.LOG .. serpent.block(data)
  end
end)

script.on_init(function()
  initglobal(true)
  if MOD.LOG then MOD.LOG = MOD.LOG .. game.tick .. ": on_init\n" end
end)

script.on_load(function()
  if MOD.LOG then MOD.LOG = MOD.LOG .. "?: on_load\n" end
end)

--
-- Game Events
--
function activate(player)
  add2global(player.name)
  local top = player.gui.top
  if top.tm_flow == nil then
    top.add({type="flow", direction="vertical", name="tm_flow"})
    top.tm_flow.add({type="flow", direction="horizontal", name="toolbar"})
    top.tm_flow.toolbar.add({ type="button", name="tm_b", caption={"test-mode.name"} })
  end
  globalPrint( {"test-mode.activated", player.name} )
end

function deactivate(player)
  removeFromglobal(player.name)
  local top = player.gui.top
  if top.tm_flow and top.tm_flow.valid then top.tm_flow.destroy() end
  globalPrint( {"test-mode.deactivated", player.name} )
end

function initglobal(reset)
  local g_names = {
    "active",
    "active_group",
    "active_searches",
    "character",
    "tab_active",
    "openrecipies",
    
    "stacksize",
    "build_options",
    "event_options",
    
    --Tool values
    "blueprint",
    "fillselected",
    "itemname",
    "lastitem",
    "resource",
    "preselectionareas", --[name] -> { posA, posB, tick, {markers},{markers} }
    "selectables",
    "selectedpos",
    "toolmode",

    --Shared values
    "auto_refill_list",
    "warps",
    "world_options"
  }
  
  if not reset then
    for i=1, #g_names do
      if global[g_names[i]] == nil then
        reset = true
        globalPrint({"test-mode.global-changed",g_names[i]})
        break
      end
    end
  end
  
  if not reset then return end
  
  --Clear global
  global = {}

  for i=1, #g_names do
    global[g_names[i]] = {}
  end

  global.world_options[1] = "test-mode.normal"
  
  if reset then
    for index, player in pairs(game.players) do
      if global.active[player.name] == nil then
        centerPopUp("clear", player)
        if player.gui.top.tm_flow then player.gui.top.tm_flow.destroy() end
        centerPopUp("activation", player)
      elseif global.active[player.name] and player.gui.top.tm_flow == nil then
        activate(player)
      end
    end
  end
end

function add2global(username, reset)
  if global.active[username] and not reset then return end
  global.active[username] = true
  global.stacksize[username] = 1
  global.build_options[username] = {false, true, true, true, true, "player"} -- {restore, destructible, mineable, operable, rotatable, force}
  global.event_options[username] = {false, false} -- {print, chunks}
  --Tool values
  global.toolmode[username] = "resource"
  global.resource[username] = "iron-ore"
end

function removeFromglobal(username)
  for k, v in pairs(global) do
    if type(v) == "table" then v[username] = nil end
  end
end

local function printevent(event, player)
  local name = get_key_for_value( defines.events, event.name )
  name = name or {"test-mode.unknown"}

  local variables = table.concat({event.area and "area = "..event.area.left_top.x..", "..event.area.left_top.y.."; "..event.area.right_bottom.x..", "..event.area.right_bottom.y or "",
                                  event.created_entity and "entity = "..event.created_entity.type..":"..event.created_entity.name or "",
                                  event.force and "force = "..event.force.name or "",
                                  event.element and "element = "..event.element.name or "",
                                  event.entity and "entity = "..event.entity.type..":"..event.entity.name or "",
                                  event.item_stack and "itemstack = +"..event.item_stack.count.." "..event.item_stack.name or "",
                                  event.position and "position = " .. event.position.x .. "," .. event.position.y or "",
                                  event.radar and "radar = " .. event.radar.name .. ": ".. event.radar.position.x .. "," .. event.radar.position.y or "",
                                  event.research and "research.name = "..event.research.name or "",
                                  event.train and "train = ".. get_key_for_value( defines.trainstate, event.train.state ) or ""
                                })

  player.print({"test-mode.e-template", event.tick, name, event.name, event.player_index or "nil", variables } )
end


local function autoRefill(event)
  local fill_list = global.auto_refill_list
  local delta, entities, filler
  
  for i=#fill_list, 1, -1 do
    delta = 0
    entities = fill_list[i][1]
    filler = fill_list[i][2]
    if entities and #entities > 0 and filler then
      if filler == "clear" then
        for j=#entities, 1 , -1  do
          if entities[j].valid and entities[j].type ~= "player" then
            delta = delta - entities[j].get_item_count()
            entities[j].clear_items_inside()
            --
          else
            table.remove(entities, j)
          end
        end
        if delta ~= 0 then
          entities[1].surface.create_entity({ name="flying-text", position=entities.center,
                                              text=delta })
        end
      else
        for j=#entities, 1 , -1 do
          if entities[j].valid and entities[j].type ~= "player" then
            delta = delta - entities[j].get_item_count(filler)
            entities[j].insert({name = filler, count = game.item_prototypes[filler].stack_size * BIGGEST_INV})
            delta = delta + entities[j].get_item_count(filler)
          else
            table.remove(entities, j)
          end
        end
        if delta ~= 0 then
          entities[1].surface.create_entity({ name="flying-text", position=entities.center,
                                              text={"", delta, " ", game.item_prototypes[filler].localised_name} })
        end
      end
    else
      table.remove(fill_list, i)
    end
  end
end

local function checkIdleTools(event) -- every third tick
  for name, tbl in pairs(global.preselectionareas) do
    if tbl[2] and tbl[3] + 60 <= event.tick then
      local toolmode = global.toolmode[name]
      if toolmode == "filler" then
        fillSelected(game.get_player(name))
      elseif toolmode == "selection" then
        selection(game.get_player(name))
      end
      global.preselectionareas[name] = nil
    end
  end
end

local function updateActiveSearches(event) -- every sec
    for name, tbl in pairs(global.active_searches) do
      if tbl[1] and tbl[1].valid then
        if tbl[1].text == "" then
          if global.active_group[username] then
            gui.addItemlist(tbl[1].player_index, global.active_group[name])
          end
        elseif tbl[1].text ~= tbl[2] then
          tbl[2] = tbl[1].text
          gui.showItemSearch(tbl[2], tbl[1].player_index)
        end
      else
        global.active_searches[name] = nil
      end
    end
end

local mod2func = {
  [0] = checkIdleTools,
  [1] = updateActiveSearches,
  [3] = checkIdleTools,
  [6] = checkIdleTools,
  [9] = checkIdleTools,
  [12] = checkIdleTools,
  [15] = checkIdleTools,
  [18] = checkIdleTools,
  [21] = checkIdleTools,
  [24] = checkIdleTools,
  [27] = checkIdleTools,
  [30] = checkIdleTools,
  [31] = autoRefill,
  [33] = checkIdleTools,
  [36] = checkIdleTools,
  [39] = checkIdleTools,
  [42] = checkIdleTools,
  [45] = checkIdleTools,
  [48] = checkIdleTools,
  [51] = checkIdleTools,
  [54] = checkIdleTools,
  [57] = checkIdleTools
}

local function ontick(event)
  local mod = event.tick % 60
  if mod2func[mod] then
    mod2func[mod](event)
  end
end

local function onguiclick(event)
  local name = event.element.name
  if name2func[name] then
    name2func[name](event.element)
  else
    local _, _, key, variable = name:find("(%a+)__(.+)")
    if name2func[key] then
      name2func[key](event.element, variable)
    end
  end
end

local function onbuiltentity(event)
  local player = game.get_player(event.player_index)
  if event.created_entity.name == "mjollnir" then
    player.insert({name="mjollnir", count=1})

    return event.created_entity.destroy()
  end
  
  if not global.active[player.name] then return end
  
  if global.build_options[player.name][1] then restore(event.created_entity.name, player) end
  if not global.build_options[player.name][2] then event.created_entity.destructible = false end
  if not global.build_options[player.name][3] then event.created_entity.minable = false end
  if not global.build_options[player.name][4] then event.created_entity.operable = false end
  if not global.build_options[player.name][5] then event.created_entity.rotatable = false end
  event.created_entity.force = game.forces[global.build_options[player.name][6]]
end


local function onputitem(event)
  if global.tick ~= nil and global.tick > event.tick then return end
  global.tick = event.tick + 5
  local player = game.get_player(event.player_index)
  local toolmode = global.toolmode[player.name]
  if global.active[player.name] and isHolding({name="mjollnir", count=1}, player) then
    if toolmode == "resource" then
      makeInfResource(player, event.position)
    elseif toolmode == "teleport" then
      moveFast(player, event.position)
    elseif toolmode == "filler" or toolmode == "selection" then
      local area = global.preselectionareas[player.name]
      local surface = game.get_surface(1)
      if area then
        area[2] = event.position
        area[3] = event.tick
        local height = area[2].y - area[1].y
        local width = area[2].x - area[1].x
        local i = 1
        for x=area[1].x, area[2].x, (area[2].x > area[1].x and 5 or -5) do
          if area[4][i] and area[4][i].valid then
            area[4][i].teleport({x, area[1].y})
          else
            area[4][i] = surface.create_entity({ name="tm-marker", position={x, area[1].y} })
          end
          i = i + 1
          if area[4][i] and area[4][i].valid then
            area[4][i].teleport({x, area[1].y + height})
          else
            area[4][i] = surface.create_entity({ name="tm-marker", position={x, area[1].y + height} })
          end
          i = i + 1
        end

        if area[4][i] and area[4][i].valid then
          area[4][i].teleport({area[2].x, area[1].y})
        else
          area[4][i] = surface.create_entity({ name="tm-marker", position={area[2].x, area[1].y} })
        end
        i = i + 1
        if area[4][i] and area[4][i].valid then
          area[4][i].teleport({area[2].x, area[1].y + height})
        else
          area[4][i] = surface.create_entity({ name="tm-marker", position={area[2].x, area[1].y + height} })
        end
        
        i = 0
        for y=area[1].y, area[2].y, (area[2].y > area[1].y and 5 or -5) do
          if i > 0 then
            if area[5][i] and area[5][i].valid then
              area[5][i].teleport({area[1].x, y})
            else
              area[5][i] = surface.create_entity({ name="tm-marker", position={area[1].x, y} })
            end
            i = i + 1
            if area[5][i] and area[5][i].valid then
              area[5][i].teleport({area[1].x + width, y})
            else
              area[5][i] = surface.create_entity({ name="tm-marker", position={area[1].x + width, y} })
            end
          end
          i = i + 1
        end
      else -- first position, new table
        global.preselectionareas[player.name] = {
          event.position, false, event.tick,
          { surface.create_entity({ name="tm-marker", position=event.position }) },
          {}
        }
      end
    end
  end
end



script.on_event(defines.events, function(event)
  if event.name ~= defines.events.on_tick then
    for index, player in pairs(game.players) do
      if global.event_options[player.name]
          and global.event_options[player.name][1] and ( event.name ~= defines.events.on_chunk_generated or global.event_options[player.name][2] ) then
        printevent(event, player)
      end
    end
  end
  if event.name == defines.events.on_tick then
    ontick(event)
  elseif event.name == defines.events.on_gui_click then
    onguiclick(event)
  elseif event.name == defines.events.on_built_entity then
    onbuiltentity(event)
  elseif event.name == defines.events.on_put_item then
    onputitem(event)
  elseif event.name == defines.events.on_player_created then
    local player = game.get_player(event.player_index)
    if global.active[player.name] then
      activate(player)
    elseif global.active[player.name] == nil then
      centerPopUp("activation", player)
    end
    if MOD.LOG then MOD.LOG = MOD.LOG .. event.tick .. ": on_player_created. index: " .. event.player_index .. "\n" end
  end
end)



--
-- Functions
--

function makeInfResource(player, pos)
	local entity = player.selected
  local surface = game.get_surface(1)
	if entity and entity.valid and entity.type == "resource" and string.find(entity.name, "__tm", 1, true) == nil then -- replace found resource
    surface.create_entity({name = entity.name .. "__tm" , position = entity.position, amount = 7500})
    entity.destroy()
	elseif surface.can_place_entity({name=global.resource[player.name], position=pos}) then
		surface.create_entity({name=global.resource[player.name] .. "__tm", position = pos, amount = 7500})
	end
end

function moveFast(player, target)
  local divider = 4 -- 100% / divider. For tuning movement speed
  deduct2Pos(target, player.position)
  --local magnitude = (target.x^2+target.y^2)^0.5
  target.x = target.x / divider
  target.y = target.y / divider
  --local telepos = addPos(player.position, target)
  --if global.teleport.avoid and not game.canplaceentity({name="player", position=telepos}) then return end
  add2Pos(target, player.position)
  player.teleport(target)
end

function selection(player)
  local area = global.preselectionareas[player.name]
  local surface = game.get_surface(1)
  local a, b
  if area[2] then
    a = {math.min(area[1].x, area[2].x), math.min(area[1].y, area[2].y)}
    b = {math.max(area[1].x, area[2].x), math.max(area[1].y, area[2].y)}
  else
    a = {area[1].x, area[1].y}
    b = a
  end

  global.selectables[player.name] = removeUnwanted(surface.find_entities{a, b})
  global.selectables[player.name].bools = {}
  if global.blueprint[player.name] == nil then global.blueprint[player.name] = {} end
  global.blueprint[player.name].newcorner = {round(a[1]), round(a[2])}
  centerPopUp("selection", player, a, b)
end

function removeUnwanted(entities)
  for i=#entities, 1, -1 do
    if entities[i].name == "mjollnir" or entities[i].type == "player"
      or entities[i].type == "corpse" or entities[i].type == "particle"
      or entities[i].type == "smoke" then
      table.remove(entities, i)
    end
  end
  return entities
end

function handleSelected(action, index)
  local player = game.get_player(index)
  local username = player.name
  if action == "paste" and type(global.blueprint[username]) == "table" then
    paste(deductPos(global.blueprint[username].newcorner, global.blueprint[username].oldcorner), player)
  elseif type(global.selectables[username]) == "table" and #global.selectables[username] > 0 then

    if action == "cut" or action == "copy" or action == "pattern" then
      global.blueprint[username] = {oldcorner = global.blueprint[username].newcorner}
    end

    local edges = {x = {max = global.selectables[username][1].position.x, min = global.selectables[username][1].position.x},
                   y = {max = global.selectables[username][1].position.y, min = global.selectables[username][1].position.y}}
    
    for i, entity in ipairs(global.selectables[username]) do

      if entity.valid and (global.selectables[username].bools[entity.name] == true) then

        if action == "cut" or action == "copy" or action == "pattern" then
          table.insert(global.blueprint[username], {name = entity.name, position=xyTo12(entity.position), direction=entity.direction,
                                        amount = entity.type=="resource" and entity.amount or nil,
                                        recipe = entity.type=="assembling-machine" and entity.recipe or nil,
                                        stack = entity.type=="item-entity" and entity.stack or nil})
          edges.x.max = math.max(edges.x.max,entity.position.x)
          edges.x.min = math.min(edges.x.min,entity.position.x)
          edges.y.max = math.max(edges.y.max,entity.position.y)
          edges.y.min = math.min(edges.y.min,entity.position.y)
        end

        if action == "remove" or action == "cut" then
          entity.destroy()
        end

      end

    end

    global.blueprint[username].edges = edges
    
    if action == "pattern" and #global.blueprint[username] > 0 then
      centerPopUp("clear", player)
      global.selectables[username] = nil
      return centerPopUp("pattern", player)
    end
    
  end

  global.selectables[username] = nil
  centerPopUp("clear", player)
end

function paste(shift, player)
  for i, bpe in ipairs(global.blueprint[player.name]) do
    local temp = table.deepcopy(bpe)
    temp.position = addPos(temp.position,shift)
    temp.force = player.force
    player.surface.create_entity(temp)
  end
end


--      patternPaste({left = -guitbl["pattern-left"].text, right = guitbl["pattern-right"].text,
--                    up = -guitbl["pattern-up"].text, down = guitbl["pattern-down"].text,
--                    gaps = {x = guitbl["pattern-gaps-x"].text,y = guitbl["pattern-gaps-y"].text},
--                    edges = global.blueprint.edges})


function patternPaste(pattern, player)
  local size = {width = pattern.edges.x.max - pattern.edges.x.min + pattern.gaps.x,
                height = pattern.edges.y.max - pattern.edges.y.min + pattern.gaps.y}
  local shift = { pattern.left*size.width, pattern.up*size.height} -- Start from lefttop-corner
                           
  for x = pattern.left, pattern.right do
  
    for y = pattern.up, pattern.down do
    
      if x == 0 and y == 0 then -- skip "source" of pattern
        --
      else
        paste(shift, player)
      end
      
      shift = addPos(shift, {0, size.height})
    end
    
    shift = {shift[1]+size.width, pattern.up*size.height}
  end

end

function fillSelected(player)
  local area = global.preselectionareas[player.name]
  local surface = game.get_surface(1)
  local a, b
  if area[2] then
    a = {math.min(area[1].x, area[2].x), math.min(area[1].y, area[2].y)}
    b = {math.max(area[1].x, area[2].x), math.max(area[1].y, area[2].y)}
  else
    a = {area[1].x, area[1].y}
    b = a
  end
  local list = surface.find_entities_filtered({area = {a, b}, force = "player"})
  
  for i=#list, 1, -1 do
    if is_fillable[list[i].type] or is_fillable[list[i].name] then -- keep in list
      if list.center then
        list.center.x = list.center.x + list[i].position.x
        list.center.y = list.center.y + list[i].position.y
      else
        list.center = list[i].position
      end
      
    else
      table.remove(list, i)
    end
  end
  
  if #list > 0 then
    list.center.x = list.center.x / #list
    list.center.y = list.center.y / #list
    global.fillselected[player.name] = list
    centerPopUp("fill", player)
  end
end



--
-- Script interface
--
remote.add_interface(MOD.IF,
{
  activate = function(username)
    username = username or ""
    local result = isValidUser(username)
    if result then
      if not global.active[username] then
        activate(result)
      else
        deactivate(result)
      end
    else
      globalPrint( {"test-mode.activation-failed", tostring(username)} )
    end
  end,
  resetglobal = function()
    initglobal(true)
  end,
  closePopUp = function(username)
    centerPopUp("clear", game.get_player(username))
  end,
  printglobal = function()
		game.show_message_dialog({text=serpent.line(global)})
  end,
  printblueprint = function()
		game.show_message_dialog({text=serpent.line(global.blueprint)})
  end,
  printLog = function()
    printToFile( MOD.LOG )
  end,
  printselected = function()
		game.show_message_dialog({text=serpent.line(global.selectables)})
  end--[[,
  inject = function(line)
		assert(loadstring(line))()
  end
--]]
})



--
-- Utilities
--

function globalPrint(msg)
  local players = game.players
  for i=1, #players do
    players[i].print({"test-mode.global-msg", msg})
  end
end

function isHolding(stack, player)
  local holding = player.cursor_stack
  if holding.valid_for_read and (holding.name == stack.name) and (holding.count >= stack.count) then
    return true
  end

  return false
end

function isValidUser(name)
  local players = game.players
  for i=1, #players do
    if players[i].name == name then
      return players[i]
    end
  end
  
  return false
end

function printToFile(line, path)
  path = path or "log"
  path = table.concat({ MOD.IF, "/", path, ".txt" })
  game.write_file( path,  line)
end

function restore(item, player)
  local ok = pcall(function () player.get_item_count(item) end)
  if not global.build_options[player.name][1] or not ok or player.get_item_count(item) >= 1 then return end
  player.insert( {name = item, count = 1} )
end

function xyTo12(pos)
  if pos.x then
    pos[1] = pos.x
    pos.x = nil
  end
  if pos.y then
    pos[2] = pos.y
    pos.y = nil
  end
  return pos
end

function addPos(apos, bpos)
	if apos.x == nil then
		return {(apos[1] + bpos[1]), (apos[2] + bpos[2])}
	else
		return {x = (apos.x + bpos.x), y = (apos.y + bpos.y)}
	end
end

function add2Pos(apos, bpos)
  if type(apos)~="table" or type(bpos)~="table" then error("add2Pos: expects 2 tables", 2) end
  if apos[1] then
    apos[1] = apos[1] + bpos[1]
    apos[2] = apos[2] + bpos[2]
  else
    apos.x = apos.x + bpos.x
    apos.y = apos.y + bpos.y
  end
end

function deductPos(apos, bpos)
	if apos.x == nil then
		return {(apos[1] - bpos[1]), (apos[2] - bpos[2])}
	else
		return {x = (apos.x - bpos.x), y = (apos.y - bpos.y)}
	end
end

function deduct2Pos(apos, bpos)
  if type(apos)~="table" or type(bpos)~="table" then error("deduct2Pos: expects 2 tables", 2) end
	if apos[1] then
    apos[1] = apos[1] - bpos[1]
    apos[2] = apos[2] - bpos[2]
	else
    apos.x = apos.x - bpos.x
    apos.y = apos.y - bpos.y
	end
end

--http://stackoverflow.com/questions/7925090/lua-find-a-key-from-a-value
function get_key_for_value( t, value )
  for k,v in pairs(t) do
    if v==value then return k end
  end
  return nil
end

--http://lua-users.org/wiki/SimpleRound
function round(num, idp)
  local mult = 10^(idp or 0)
  return math.floor(num * mult + 0.5) / mult
end        
