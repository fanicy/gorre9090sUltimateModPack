local resource_array = {}
local new_resource

for name, resource in pairs(data.raw.resource) do
  new_resource = {}
  --Shallow Copy
  for k, v in pairs(resource) do
    new_resource[k] = v
  end
  --new_resource.minimum = new_resource.infinite and 7500 or 1
  new_resource.name = name .. "__tm"
  new_resource.infinite = true
  new_resource.minimum = 7500
  new_resource.autoplace = nil
  resource_array[#resource_array + 1] = new_resource
end

data:extend(resource_array)